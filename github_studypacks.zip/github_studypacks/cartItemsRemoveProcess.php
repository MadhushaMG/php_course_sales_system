<?php

require "connection.php";

if(isset($_GET["id"])){

    $cart_id = $_GET["id"];

    $cart_rs = Database::search("SELECT * FROM `cart` WHERE `id`='".$cart_id."' ");
    $cart_num = $cart_rs->num_rows;

    if($cart_num == 1){

        Database::iud("DELETE FROM `cart` WHERE `id` = '".$cart_id."'");
        echo("success");


    }else{
        echo("Cannot find the item. Please try again later.");
    }

}else{
    echo ("Something went wrong.");
}

?>