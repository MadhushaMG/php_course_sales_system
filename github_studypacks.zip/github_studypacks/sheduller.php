<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sheduller</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row">
            <span class="text-start">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Course sheduller</li>
                    </ol>
                </nav>
            </span>
            <div class="col-lg-12 col-12">
                <span class="fw-bold fs-6 text-uppercase "><i class="bi bi-caret-right-fill"></i>Shedule panel</span>
                <div class="card mt-3  container-fluid  border border-0 bg-light">
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <div class="col-lg-6 col-12 mt-2">
                                <span class="fs-6">Course name</span>
                                <div class="col-lg-12 col-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-6">
                                            <select class="form-select" id="selectCourse">
                                                <?php

                                                require "connection.php";

                                                $rs = Database::search("SELECT * FROM `course`");
                                                $n = $rs->num_rows;

                                                for ($x = 0; $x < $n; $x++) {
                                                    $d = $rs->fetch_assoc();

                                                ?>
                                                    <option value="<?php echo $d["id"]; ?>"><?php echo $d["name"]; ?></option>

                                                <?php

                                                }

                                                ?>
                                            </select>
                                        </div>
                                        <div class="col-lg-6 col-6">
                                            <select class="form-select" id="connectionType" onchange="updateGreeting()">
                                                <?php

    
                                                $rs = Database::search("SELECT * FROM `shedule_type`");
                                                $n = $rs->num_rows;

                                                for ($x = 0; $x < $n; $x++) {
                                                    $d = $rs->fetch_assoc();

                                                ?>
                                                    <option><?php echo $d["type"]; ?></option>

                                                <?php

                                                }

                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-12 mt-2" id="ocs1">
                                <span class="fs-6" id="tst">Date</span>
                                <input type="date" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="sheduleDate">
                            </div>
                            <div class="col-lg-6 col-12 mt-2 mb-3" id="ocs2">
                                <span class="fs-6">Time</span>
                                <input type="time" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="sheduleTime">
                            </div>

                            <div class="col-lg-6 col-12 mt-2 mb-3">
                                <span class="fs-6">Link</span>
                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="zoomLink" placeholder="zoom link">
                            </div>
                            <div class="text-end text-uppercase"><span id="msgshedule" class="text-info fs-6"></span></div>
                            <div class="col-lg-12 col-12 mt-3 mb-1 text-end">
                                <button class="btn btn-danger" onclick="sheduller();" id="ssb">Save</button>
                                <div class="btn-group d-none" id="sab">
                                    <button class="btn btn-danger" onclick="updatesheduleData();" id="ssb">Update</button>
                                    <a href="#" class="btn btn-light" onclick="loadContent('sheduller.php');"><i class="bi bi-calendar-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-12 mt-3 container-fluid">
                <span class="fw-bold fs-6 text-uppercase "><i class="bi bi-caret-right-fill"></i>Preview area</span>
                <div class="maoscroll border border-0 bg-light container-fluid" style="height:50vh;">
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <?php

                            $d = new DateTime();
                            $tz = new DateTimeZone("Asia/Colombo");
                            $d->setTimezone($tz);
                            $dateNew = $d->format("Y-m-d H:i:s");


                            $crs_rs = Database::search("SELECT * FROM `shedule` ORDER BY `date` ASC");
                            $crs_num = $crs_rs->num_rows;


                            for ($x = 0; $x < $crs_num; $x++) {
                                $cData = $crs_rs->fetch_assoc();
                                $course = Database::search("SELECT * FROM `course` WHERE `id` = '" . $cData['course_id'] . "'");
                                $courseData = $course->fetch_assoc();

                            ?>
                                <div class="col-lg-3 col-12 mt-2">
                                    <div class="card" style="width: 100%;">
                                        <div class="card-header">
                                            <?php
                                            if(empty($cData['date'])){ ?>
                                                <span class="badge text-bg-primary">Recorded</span>
                                            <?php }else{ ?>
                                                <span class="badge text-bg-primary fs-6 opacity-75"><?php echo  $cData['date']; ?></span>
                                           <?php }
                                            ?>
                                            
                                            
                                        </div>
                                        <div class="card-body">
                                            <h6 class="card-title text-uppercase text-muted"><i class="bi bi-tag"></i> <?php echo $courseData["name"]; ?></h6>
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase"><i class="bi bi-person"></i> <?php echo $courseData["lecturer_name"]; ?></h6>
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase">
                                            
                                            <?php 
                                            if(empty($cData['time'])){?>
                                                 <i class="bi bi-alarm"></i> Anytime
                                            <?php }else{ ?>
                                                <i class="bi bi-alarm"></i> <?php echo  $cData['time']; ?>
                                           <?php }
                                            
                                            ?>
                                            
                                            </h6>
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase">
                                            <?php 
                                            if($cData['shedule_type_id'] == 1){?>
                                                <i class="bi bi-wifi"></i> <?php echo "Online";?> 
                                            <?php }else{ ?>
                                                <i class="bi bi-wifi-off"></i> <?php echo "Offline"; ?> 
                                           <?php }
                                            
                                            ?>
                                        </h6>
                                            <hr class="border border-3 border-dark" />
                                            <div class="col-lg-12 col-12">
                                                <div class="row">
                                                    <div class="btn-group">
                                                        <a href="<?php echo $cData["link"]; ?>" target="_blank" + class="btn btn-primary active" aria-current="page">Click here to join</a>
                                                        <a href="#" class="btn btn-primary" onclick="updateShedule(<?php echo $cData['id']; ?>);"><i class="bi bi-arrow-repeat"></i></a>
                                                        <a href="#" class="btn btn-primary" onclick="deleteShedule(<?php echo $cData['id']; ?>);"><i class="bi bi-trash"></i></a>
                                                    </div>
                                                    <div>


                                                    </div>

                                                </div>
                                            </div>

                                            </p>

                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>