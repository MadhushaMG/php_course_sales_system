<?php

require "connection.php";
require "SMTP.php";
require "PHPMailer.php";
require "Exception.php";

use PHPMailer\PHPMailer\PHPMailer;

$fname = $_POST["f"];
$lname = $_POST["l"];
$email = $_POST["e"];
$password = $_POST["pw"];
$mobile = $_POST["n"];


if (empty($fname)) {
    echo ("Please enter your First Name !!!");
} else if (strlen($fname) > 50) {
    echo ("First Name must have less than 50 characters");
} else if (empty($lname)) {
    echo ("Please enter your Last Name !!!");
} else if (strlen($lname) > 50) {
    echo ("Last Name must have less than 50 characters");
} else if (empty($email)) {
    echo ("Please enter your Email !!!");
} else if (strlen($email) >= 100) {
    echo ("Email must have less than 100 characters");
} else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo ("Invalid Email !!!");
} else if (empty($password)) {
    echo ("Please enter your Password !!!");
} else if (strlen($password) < 5 || strlen($password) > 20) {
    echo ("Password must be between 5 - 20 charcters");
} else if (empty($mobile)) {
    echo ("Please enter your Mobile !!!");
} else if (strlen($mobile) != 10) {
    echo ("Mobile must have 10 characters");
} else if (!preg_match("/07[0,1,2,4,5,6,7,8][0-9]/", $mobile)) {
    echo ("Invalid Mobile !!!");
} else {

    $rs = Database::search("SELECT * FROM `user` WHERE `email`='" . $email . "' OR `mobile`='" . $mobile . "'");
    $n = $rs->num_rows;

    if ($n > 0) {
        echo ("User with the same Email or Mobile already exists.");
    } else {
        $d = new DateTime();
        $tz = new DateTimeZone("Asia/Colombo");
        $d->setTimezone($tz);
        $date = $d->format("Y-m-d H:i:s");

               //email sending process

               $code = uniqid();

               Database::iud("INSERT INTO `user` (`fname`,`lname`,`email`,`mobile`,`password`,`user_type_id`,`,`otp`,`status`) VALUES ('" . $fname . "','" . $lname . "','" . $email . "','" . $mobile . "','" . $password . "','2','".$code."','1')");
               $mail = new PHPMailer;
               $mail->IsSMTP();
               $mail->Host = 'smtp.gmail.com';
               $mail->SMTPAuth = true;
               $mail->Username = 'test.application200@gmail.com';
               $mail->Password = 'rxelvllqxudovixm';
               $mail->SMTPSecure = 'ssl';
               $mail->Port = 465;
               $mail->setFrom('test.application200@gmail.com', 'Verify Account');
               $mail->addReplyTo('test.application200@gmail.com', 'Verify Account');
               $mail->addAddress($email);
               $mail->isHTML(true);
               $mail->Subject = 'test.application200@gmail.com';
               $bodyContent = '
               
               
                
               <!DOCTYPE html>
       <html lang="en">
       
       <head>
           <title>Email verify</title>
       
           <link rel="stylesheet" href="bootstrap.css" />
           <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
           <link rel="stylesheet" href="style.css" />
       </head>
       
       <body>
           <div class="col-lg-12 col-12 container-fluid">
               <div class="row">
                   <div class=" col-lg-10 offset-1 col-12 emb ">
                       <h1 class=" fw-bold  ">CODPLUS</h1><br />
                       <h2 class=" fw-bold  ">ACCOUNT VERIFICATION</h2>
                       <br />
                       <hr />
       
                       <h3>Good day ' . $fname . ' ,welcome to STUDY-PACKS. You have completed one step of accessing our system. 
                           You need to verify your email address for system access. Enter the verification code below.<br/><br/>
                           
                           <div style="margin-left: 40%; background-color:red; width:20%; text-align:center; font-weight: bold;">' . $code . '</div>
       
       
                       </h3>
                           <br/><br/><br/>
                           <br/><br/><br/>
                           <br/><br/><br/>
                           <h6 style="text-align: center;">PLEASE NOTE THAT THIS IS A SYSTEM-GENERATED EMAIL. <br/><small class=" text-uppercase">Copyright © 2022 CODARA All Rights Reserved</small></h6>
                   </div>
               </div>
           </div>
       </body>
       
       </html>
               
               ';
               $mail->Body    = $bodyContent;
       
               if (!$mail->send()) {
                   echo 'Verification code sending failed';
               } else {
                   echo 'success';
               }
        
        

   
    }
}

?>
