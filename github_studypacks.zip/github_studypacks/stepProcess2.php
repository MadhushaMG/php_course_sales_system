<?php

require "connection.php";

$mobile = $_POST["n"];
$password = $_POST["pw"];
$rpassword = $_POST["prw"];

if(empty($mobile)){
    echo ("Please enter your Mobile !!!");
}else if(strlen($mobile) != 10){
    echo ("Mobile must have 10 characters");
}else if(!preg_match("/07[0,1,2,4,5,6,7,8][0-9]/",$mobile)){
    echo ("Invalid Mobile !!!");
}else if (empty($password)){
    echo ("Please enter your Password !!!");
}else if(strlen($password) < 5 || strlen($password) > 20){
    echo ("Password must be between 5 - 20 charcters");
}else if($password != $rpassword){
    echo ("Not matched password. please check your password again.");
}else {
    $rs = Database::search("SELECT * FROM `user` WHERE `mobile`='" . $mobile. "'");
    $n = $rs->num_rows;
    if ($n > 0) {
        echo ("User with the same mobile number already exists.");
    } else{
        echo "success";
    }
}

?>
