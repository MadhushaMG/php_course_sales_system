<?php
session_start();
?>
<?php

require "connection.php";

$id1 = $_GET["id1"];
$id2 = $_GET["id2"];

$rs = Database::search("SELECT * FROM `course_marks` WHERE (`shedule_id`='" . $id1 . "') AND (`status` = '1')");
$rs_n = $rs->num_rows;

if($rs_n == 1){
    echo("watched");
}else{
    Database::iud("INSERT INTO `course_marks` (`shedule_id`, `user_has_course_id`, `status`) VALUES ('" . $id1 . "', '" . $id2 . "', '1')");
    echo("not_watched");
}

?>
