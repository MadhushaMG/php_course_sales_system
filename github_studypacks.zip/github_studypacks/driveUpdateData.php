<?php
require("connection.php");

// Get the ID from the query parameters
$id = $_GET['id'];

// Fetch data from the database based on the ID
$result =  Database::search("SELECT * FROM `shedule` WHERE `id` = $id");


if ($result) {
    // Check if any rows were returned
    if (mysqli_num_rows($result) > 0) {
        // Fetch the first row
        $data = mysqli_fetch_assoc($result);

        // Return the data as JSON
        echo json_encode($data);
    } else {
        echo "No data found for the given ID";
    }
} else {
    echo "Error executing the query: " . mysqli_error($connection);
}

?>
