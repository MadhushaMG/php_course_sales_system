<?php

session_start();
require "connection.php";

if(isset($_POST["snTextArea"])){

    $snTextArea= $_POST["snTextArea"];
 
    if(empty($snTextArea)){
        echo ("Enter your notice");
    }else{
  

    Database::iud("UPDATE `notes` SET `notes` = '".$snTextArea."'  WHERE `id` = '1'");

    echo("success");
    }
    
}else{
    echo ("Something went wrong.");
}

?>