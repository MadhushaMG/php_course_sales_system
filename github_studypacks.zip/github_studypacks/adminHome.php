<?php

session_start();
if (isset($_SESSION["u"])) {
    include "connection.php";

    $user_rs = Database::search("SELECT * FROM `user` WHERE `email`='" . $_SESSION['u']["email"] . "'");
    $user_data = $user_rs->fetch_assoc();


?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Home</title>
    </head>

    <body>
        <div class="col-lg-12 col-12 container-fluid">
            <div class="row">
                <?php

                $aa_rs = Database::search("SELECT * FROM `user_has_course` WHERE `payment_status`='0' AND ('1' = '" . $_SESSION['u']['user_type_id'] . "')");
                $aa_num = $aa_rs->num_rows;

                if ($aa_num >= 1) { ?>
                    <div>
                        <div class="card card-body text-white fw-bold mt-1" style=" background-color: #000000a7; cursor:pointer;" onclick="loadContent('teacherApprove.php')">
                            There is <?php echo ($aa_num); ?> person to approve. Please go to the Approve tab and check.
                            <span class="end-0 position-absolute fs-4 top-0" style="margin-right: 10px; "><i class="bi bi-exclamation-octagon"></i></span>
                        </div>
                    </div>
                <?php }

                ?>
                <div class="col-lg-12 col-12 mt-3">
                    <div class="card mb-4 bg-success text-white bg-opacity-75">
                        <div class="col-lg-12 col-12">
                            <div class="row">
                                <div class="col-lg-12 col-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-6">
                                            <span class="fw-bold fs-6 text-uppercase "><i class="bi bi-caret-right-fill"></i>Special notice</span>
                                        </div>

                                    </div>

                                </div>
                                <div class="col-lg-12 col-12">
                                    <div class="row container-fluid">
                                        <div class="col-lg-12 col-12">
                                            <?php
                                            $sn_rs = Database::search("SELECT * FROM `notes`");
                                            $sn_data = $sn_rs->fetch_assoc();
                                            ?>
                                            <marquee><span><?php echo ($sn_data['notes']); ?></span></marquee>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 col-12">
                    <div class="card mb-4 mt-1">
                        <div class="col-lg-12 col-12">
                            <div class="row">
                                <div class="col-lg-12 col-12">
                                    <span class="fw-bold fs-6 text-uppercase "><i class="bi bi-caret-right-fill"></i> Profile</span>
                                </div>
                                <div class="col-lg-12 col-12 text-center">

                                </div>
                                <div class="col-lg-12 col-12">
                                    <div class="row">
                                        <div class="col-lg-12 col-12 mt-2">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control border-0 mt-2" id="floatingInput" value="<?php echo ($user_data["fname"]); ?>" disabled>
                                                <label for="floatingInput">First Name</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control border-0 mt-2" id="floatingInput" value="<?php echo ($user_data["lname"]); ?>" disabled>
                                                <label for="floatingInput">Second Name</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control border-0 mt-2" id="floatingInput" value="<?php echo ($user_data["email"]); ?>" disabled>
                                                <label for="floatingInput">Email</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control border-0 mt-2" id="floatingInput" value="<?php echo ($user_data["mobile"]); ?>" disabled>
                                                <label for="floatingInput">Mobile</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input type="password" class="form-control border-0 mt-2" id="floatingInput" value="<?php echo ($user_data["password"]); ?>" disabled>
                                                <label for="floatingInput">Password</label>
                                            </div>

                                        </div>
                                        <div class="col-lg-12 col-12 text-center mt-2 mb-3 ">
                                            <div class="btn-group container-fluid" role="group" aria-label="Basic mixed styles example">
                                                <button type="button" class="btn btn-danger" onclick="loadContent('updateProfile.php')">Change</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card col-lg-8 col-12 border-0">
                    <div class="col-lg-12 col-12">
                        <div class="row">

                            <div class="col-lg-6 col-12 mt-1">
                                <div class="card mb-4">
                                    <div class="col-lg-12 col-12">
                                        <div class="row">
                                            <div class="col-lg-12 col-12">
                                                <span class="fw-bold fs-6 text-uppercase "><i class="bi bi-caret-right-fill"></i> Users</span>
                                            </div>
                                            <div class="col-lg-12 col-12 mb-3">
                                                <div class="row container-fluid">
                                                    <div class="col-lg-12 col-12">
                                                        <?php
                                                        $t_rs = Database::search("SELECT * FROM `user`");
                                                        $t_num = $t_rs->num_rows;
                                                        $ao_rs = Database::search("SELECT * FROM `user` WHERE `user_type_id`='2'");
                                                        $ao_num = $ao_rs->num_rows;

                                                        ?>

                                                        <label class="mt-2">Count Of Students(<?php echo ($ao_num); ?>)</label>
                                                        <div class="progress">
                                                            <div class="progress-bar text-start" role="progressbar" aria-label="Basic example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo round($ao_num, 2); ?>%">&nbsp;&nbsp;<?php echo round($ao_num, 2); ?>%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-12 mt-1">
                                <div class="card mb-4">
                                    <div class="col-lg-12 col-12">
                                        <div class="row">
                                            <div class="col-lg-12 col-12">
                                                <span class="fw-bold fs-6 text-uppercase "><i class="bi bi-caret-right-fill"></i>Course infomation</span>
                                            </div>
                                            <div class="col-lg-12 col-12 mb-3">
                                                <div class="row container-fluid">
                                                    <div class="col-lg-12 col-12">
                                                        <?php
                                                        $fc_rs = Database::search("SELECT * FROM `course`");
                                                        $fc_num = $fc_rs->num_rows;
                                                        $c_rs = Database::search("SELECT * FROM `user_has_course` WHERE `user_id`='" . $_SESSION['u']["id"] . "'");
                                                        $c_num = $c_rs->num_rows;
                                                        $coc = (($c_num / $fc_num) * 100);
                                                        ?>
                                                        <label class="mt-1">Count of my course : </label>
                                                        <span><?php echo  $c_num; ?></span>
                                                        <div class="progress">
                                                            <div class="progress-bar text-start" role="progressbar" aria-label="Basic example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo round($coc, 2); ?>%"></div>
                                                        </div>
                                                        <label class="mt-1">My courses</label>
                                                        <div class="courseView">
                                                            <?php
                                                            for ($x = 0; $x < $c_num; $x++) {
                                                                $coData = $c_rs->fetch_assoc();
                                                                $coDataRow = Database::search("SELECT * FROM `course` WHERE `id` = '" . $coData['course_id'] . "'");
                                                                $coDataNew = $coDataRow->fetch_assoc();
                                                            ?>


                                                                <span><i class="bi bi-arrow-right-short"></i> <?php echo ($coDataNew['name']); ?></span><br />

                                                            <?php }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-12 mt-1">
                                <div class="col-lg-12 col-12 mt-3">
                                    <div class="card mb-4">
                                        <div class="col-lg-12 col-12">
                                            <div class="row">
                                                <div class="col-lg-12 col-12">
                                                    <span class="fw-bold fs-6 text-uppercase "><i class="bi bi-caret-right-fill"></i>Shortcut</span>
                                                </div>
                                                <div class="col-lg-12 col-12 mb-3">
                                                    <div class="row container-fluid">
                                                        <div class="col-lg-12 col-12">
                                                            <div class="btn-group mb-3" role="group" aria-label="Basic outlined example">
                                                                <button type="button" class="btn btn-outline-white btn-outline-light text-dark" onclick="loadContent('updateProfile.php')"><i class="bi bi-pencil-square"></i></button>
                                                                <button type="button" class="btn btn-outline-white btn-outline-light text-dark text-uppercase" data-bs-toggle="modal" data-bs-target="#exampleModal">Add New Reports <i class="bi bi-plus-circle"></i></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Add new reports</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="input-group input-group-sm mb-3">
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="add new reports" id="addReports">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary" onclick="addNR();">Sent reports</button>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>

            </div>
        </div>
    </body>

    </html>

<?php

} else {
    exit();
}
?>