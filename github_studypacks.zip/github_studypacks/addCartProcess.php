<?php

session_start();
require "connection.php";


if(isset($_GET["id"])){

    $cart_id = $_GET["id"];

    Database::iud("INSERT INTO `cart` (`course_id`, `user_id`,`status`) VALUES ('".$cart_id."', '". $_SESSION['u']["id"] ."','1')");
    echo("success");

}else{
    echo ("Something went wrong.");
}

?>