<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>userSession</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body class=" bg-dark">
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row">
            <div class="text-center mt-5">
                <img src="resources/systemImages/animated-computer-image-0028.gif" style="width: 100px" /><br/>
                <span class="fs-3 fw-bold text-uppercase text-white">You are Not a valid user</span><br/>
                <hr class=" text-white border border-3"/>
                <span class="fs-6 text-white text-uppercase text-opacity-50">
                If your Internet connection is unstable, periodically disconnecting and reconnecting, it can cause a website session to expire. When the Internet connection is lost the website connection can be terminated,
                 resulting in a session expired message if you try to access any page after the Internet reconnects.
                 <hr class=" text-white border border-3"/>
                </span><br/>
                <a href="index.php"><button class="btn btn-danger mt-5">GOTO SIGNIN</button></a>
                <a href="stuSignUp.php"><button class="btn btn-danger mt-5">GOTO SIGNUP</button></a>
            </div>
        </div>
    </div>

    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>