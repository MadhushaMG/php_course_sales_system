<?php
session_start();
require "connection.php";  // Assuming this file contains your database connection code

// Get the status from the AJAX request
$status = isset($_POST['status']) ? intval($_POST['status']) : null;  // Ensure the status is an integer

if ($status !== null && ($status === 0 || $status === 1)) {

    Database::iud("UPDATE `user` SET `login_id`='" . $status . "' WHERE 
    `id`='" . $_SESSION["u"]["id"] . "'");
    if ($status == 0) {
        $_SESSION["u"] = null;
        session_destroy();
    }else{
        $_SESSION["u"];
    }
} else {
    echo "Invalid status value.";
}
