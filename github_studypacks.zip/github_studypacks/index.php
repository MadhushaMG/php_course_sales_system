<!-- Developer status |
Name : Madhusha M. Gunasekara |
Contact us : madhushamalsara@gmail.com -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | studypacks</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="style.css" />
    <link rel="shortcut icon" href="./resources/systemImages/mortarboard.png" type="image/png">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />


    <script>

    </script>

</head>

<body>
    <!-- Preloader -->
    <div class="preloader" id="preloader">
        <img src="./resources/systemImages/loading.svg" alt="Loading" class="primg">
    </div>
    <?php require "indexHeader.php" ?>
    <div class="col-lg-12 col-12 container-fluid main">
        <div class="row">
            <div class="col-lg-12 col-12 bgni mt-4">
                <hr class="text-light mt-0" />
                <div class="mt-5 text-center text-white topicspace">
                    <h2 class="fw-bold  text-uppercase"><span class="htcani1">Knowledge is</span><span class="htcani2">
                            your power</span></h2>
                    <h4 class="fs-5 text-uppercase">www.studypacks.lk</h4>
                </div>
                <div class="mt-4 text-center text-info ">
                    <h5 class="fs-6">Ready to studey? Enter your email to create or restart your membership.</h5>
                </div>
                <div class="col-lg-12 col-12 mb-5">
                    <div class="row">
                        <div class="col-lg-3"></div>
                        <div class="col-lg-6 col-12 mb-5">
                            <div class="input-group mb-3 input-group-md">
                                <input type="text" class="form-control" placeholder="username@company.com" aria-describedby="button-addon2" id="email">
                                <span class="input-group-text text-uppercase bg-danger border border-0 text-light" type="button" onclick="umailcheck();" id="emailbtn">Get Start <i class="bi bi-arrow-right"></i></span>
                            </div>

                            <div class="d-none" id="uemailerror">
                                <div class="card card-body text-white bgwarningimg text-uppercase" id="msg1"></div>
                            </div>
                        </div>
                        <div class="col-lg-3"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 col-12 container-fluid mt-4 bg-light">
                <div class="col-lg-12 col-12 mt-2 mb-2">
                    <div class="row">
                        <div id="carouselExample" class="carousel slide">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="col-lg-12 col-12">
                                        <div class="row">
                                            <div class="col-lg-4 col-12">
                                                <div class="card chr">
                                                    <div class="card-body">
                                                        <div class="colg-12 col-12 col-12">
                                                            <div class="row">
                                                                <div class="col-lg-3 col-3 text-center">
                                                                    <i class="bi bi-bank2 fs-1"></i>
                                                                </div>
                                                                <div class="col-lg-9 col-9">
                                                                    <h5 class="card-title fw-bold">Easy payment scheme</h5>
                                                                    <h6 class="card-subtitle mb-2 text-body-secondary">Multiple online
                                                                        payment schemes customized to your requirements</h6>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-12 ">
                                                <div class="card chr">
                                                    <div class="card-body">
                                                        <div class="colg-12 col-12 col-12">
                                                            <div class="row">
                                                                <div class="col-lg-3 col-3 text-center">
                                                                    <i class="bi bi-mortarboard fs-1"></i>
                                                                </div>
                                                                <div class="col-lg-9 col-9">
                                                                    <h5 class="card-title fw-bold">Convenient online experience
                                                                    </h5>
                                                                    <h6 class="card-subtitle mb-2 text-body-secondary">Superior
                                                                        online
                                                                        features make your learning experience truly amazing and
                                                                        results
                                                                        generating</h6>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-12">
                                                <div class="card chr">
                                                    <div class="card-body">
                                                        <div class="colg-12 col-12 col-12">
                                                            <div class="row">
                                                                <div class="col-lg-3 col-3 text-center">
                                                                    <i class="bi bi-people-fill fs-1"></i>
                                                                </div>
                                                                <div class="col-lg-9 col-9">
                                                                    <h5 class="card-title fw-bold">Experienced & leading lecture
                                                                        panel</h5>
                                                                    <h6 class="card-subtitle mb-2 text-body-secondary">Leading
                                                                        lecturers
                                                                        with successful results are available in the platform
                                                                    </h6>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="col-lg-12 col-12">
                                        <div class="row">
                                            <div class="col-lg-4 col-12">
                                                <div class="card chr">
                                                    <div class="card-body">
                                                        <div class="colg-12 col-12 col-12">
                                                            <div class="row">
                                                                <div class="col-lg-3 col-3 text-center">
                                                                    <i class="bi bi-bank2 fs-1"></i>
                                                                </div>
                                                                <div class="col-lg-9 col-9">
                                                                    <h5 class="card-title fw-bold">Easy payment scheme</h5>
                                                                    <h6 class="card-subtitle mb-2 text-body-secondary">Multiple online
                                                                        payment schemes customized to your requirements</h6>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-12 ">
                                                <div class="card chr">
                                                    <div class="card-body">
                                                        <div class="colg-12 col-12 col-12">
                                                            <div class="row">
                                                                <div class="col-lg-3 col-3 text-center">
                                                                    <i class="bi bi-mortarboard fs-1"></i>
                                                                </div>
                                                                <div class="col-lg-9 col-9">
                                                                    <h5 class="card-title fw-bold">Convenient online experience
                                                                    </h5>
                                                                    <h6 class="card-subtitle mb-2 text-body-secondary">Superior
                                                                        online
                                                                        features make your learning experience truly amazing and
                                                                        results
                                                                        generating</h6>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-12">
                                                <div class="card chr">
                                                    <div class="card-body">
                                                        <div class="colg-12 col-12 col-12">
                                                            <div class="row">
                                                                <div class="col-lg-3 col-3 text-center">
                                                                    <i class="bi bi-people-fill fs-1"></i>
                                                                </div>
                                                                <div class="col-lg-9 col-9">
                                                                    <h5 class="card-title fw-bold">Experienced & leading lecture
                                                                        panel</h5>
                                                                    <h6 class="card-subtitle mb-2 text-body-secondary">Leading
                                                                        lecturers
                                                                        with successful results are available in the platform
                                                                    </h6>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <button class="carousel-control-prev d-lg-block d-none" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon bg-dark rounded rounded-circle" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next d-lg-block d-none" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                                <span class="carousel-control-next-icon bg-dark rounded rounded-circle" aria-hidden="true"></span>
                                <span class="visually-hidden ">Next</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- About Start -->
            <div class="container-xxl py-5" id="about">
                <div class="container">
                    <div class="row g-5">
                        <div class="col-lg-6 wow fadeInUp d-lg-block d-none" data-wow-delay="0.1s" style="min-height: 400px;">
                            <div class="position-relative h-100">
                                <img class="img-fluid position-absolute w-100 h-100" src="./resources/systemImages/slider-dec.png" alt="" style="object-fit: cover;">
                            </div>
                        </div>
                        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                            <h6 class="section-title bg-white text-start text-primary pe-3 htopic">About Us</h6>
                            <h2 class="mb-4 htopic">Welcome to STUDY-PACKS</h2>
                            <p class="mb-4">Welcome to Studypacks, where education meets innovation! At Studypacks, we
                                are dedicated to providing students with a cutting-edge online learning experience that
                                goes beyond the traditional classroom. </p>
                            <p class="mb-4">Our platform offers a comprehensive range of subjects through engaging
                                online classes, ensuring that students have access to high-quality education anytime,
                                anywhere.</p>
                            <div class="row gy-2 gx-4 mb-4">
                                <div class="col-sm-6">
                                    <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Skilled
                                        Instructors</p>
                                </div>
                                <div class="col-sm-6">
                                    <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Online Classes
                                    </p>
                                </div>
                                <div class="col-sm-6">
                                    <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Certificate</p>
                                </div>
                                <div class="col-sm-6">
                                    <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>24/7 support</p>
                                </div>
                                <div class="col-sm-6">
                                    <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Best dashboard
                                    </p>
                                </div>
                                <div class="col-sm-6">
                                    <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>recorded videos
                                    </p>
                                </div>
                            </div>
                            <a class="btn btn-primary py-3 px-5 mt-2" href="">Read More</a>
                        </div>
                    </div>
                </div>

            </div>
            <!-- About End -->

            <div class="col-lg-10 offset-lg-1 col-12 container-fluid">
                <div class="row">
                    <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                        <h6 class="section-title bg-white text-center text-primary px-3 htopic">Courses</h6>
                        <h1 class="mb-1 htopic">Popular Courses</h1>
                    </div>
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <nav class="nav container-fluid">
                                <a class="nav-link active bg-light" onclick="index_step1();">WHAT IS STUDY-PACKS</a>
                                <a class="nav-link" onclick="index_step2();">COURSES</a>
                                <a class="nav-link" onclick="index_step3();">HELP-DESK</a>
                            </nav>
                            <hr />

                            <div class="d-block" id="index_c1">
                                h                           
                             </div>
                            <div class="d-none" id="index_c2">
                                    t
                            </div>
                            <div class="d-none" id="index_c3">
                                    Some placeholder content for the collapse component. This panel is hidden by default but revealed when the user activates the relevant trigger.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Courses Start -->
            <div class="container-xxl py-5">
                <div class="container">
                    <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                        <h6 class="section-title bg-white text-center text-primary px-3 htopic">Courses</h6>
                        <h1 class="mb-5 htopic">Popular Courses</h1>
                    </div>
                    <div class="row g-4 justify-content-center">
                        <div class="col-lg-12 col-12">
                            <div class="row">
                                <?php

                                $course = Database::search("SELECT * FROM `course`");
                                $coursen = $course->num_rows;
                                if ($coursen > 3) {
                                    for ($y = 0; $y < 3; $y++) {
                                        $cData = $course->fetch_assoc(); ?>

                                        <div class="col-lg-4 col-md-6 wow fadeInUp mt-2" data-wow-delay="0.3s">
                                            <div class="course-item bg-light">
                                                <div class="position-relative overflow-hidden">
                                                    <img class="img-fluid" src="./resources/systemImages/bgn.svg" alt="">
                                                    <div class="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                                                        <a href="#" class="flex-shrink-0 btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                                        <a href="#" class="flex-shrink-0 btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">Join Now</a>
                                                    </div>
                                                </div>
                                                <div class="text-center p-4 pb-0">
                                                    <h3 class="mb-0">LKR.<?php echo $cData["price"]; ?></h3>
                                                    <div class="mb-3">
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small>(123)</small>
                                                    </div>
                                                    <h5 class="mb-4"><?php echo $cData['name']; ?></h5>
                                                </div>
                                                <div class="d-flex border-top">
                                                    <small class="flex-fill text-center border-end py-2"><i class="fa fa-user-tie text-primary me-2"></i><?php echo $cData["lecturer_name"]; ?></small>
                                                    <small class="flex-fill text-center border-end py-2"><i class="fa fa-clock text-primary me-2"></i>1.49 Hrs</small>
                                                    <small class="flex-fill text-center py-2"><i class="fa fa-user text-primary me-2"></i>30 Students</small>
                                                </div>
                                            </div>
                                        </div>

                                    <?php  }
                                } else {
                                    for ($y = 0; $y < $coursen; $y++) {
                                        $cData = $course->fetch_assoc(); ?>

                                        <div class="col-lg-4 col-md-6 wow fadeInUp mt-2" data-wow-delay="0.3s">
                                            <div class="course-item bg-light">
                                                <div class="position-relative overflow-hidden">
                                                    <img class="img-fluid" src="./resources/systemImages/bgn.svg" alt="">
                                                    <div class="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                                                        <a href="#" class="flex-shrink-0 btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                                        <a href="#" class="flex-shrink-0 btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">Join Now</a>
                                                    </div>
                                                </div>
                                                <div class="text-center p-4 pb-0">
                                                    <h3 class="mb-0">LKR.<?php echo $cData["price"]; ?></h3>
                                                    <div class="mb-3">
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small class="fa fa-star text-primary"></small>
                                                        <small>(123)</small>
                                                    </div>
                                                    <h5 class="mb-4"><?php echo $cData['name']; ?></h5>
                                                </div>
                                                <div class="d-flex border-top">
                                                    <small class="flex-fill text-center border-end py-2"><i class="fa fa-user-tie text-primary me-2"></i><?php echo $cData["lecturer_name"]; ?></small>
                                                    <small class="flex-fill text-center border-end py-2"><i class="fa fa-clock text-primary me-2"></i>1.49 Hrs</small>
                                                    <small class="flex-fill text-center py-2"><i class="fa fa-user text-primary me-2"></i>30 Students</small>
                                                </div>
                                            </div>
                                        </div>

                                <?php }
                                }
                                ?>

                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Courses End -->


        </div>
        <div class="col-lg-12 col-12 container-fluid">
            <div class="row">
                <h4 class="mt-0 fs-4  htopic">Frequently Asked Questions</h4>
            </div>

            <div class="row g-0 position-relative">
                <div class="col-md-12 p-4  text-white">
                    <div class="col-lg-12 col-12 container-fluid">
                        <div class="row">
                            <div class="col-lg-10 col-12 offset-lg-1">
                                <button type="button" class="btn btn-dark w-100 text-start"><span class="fs-6 position-absolute">What is codplus?</span>
                                    <div class="text-end"><i class="bi bi-plus-lg fs-6" data-bs-toggle="collapse" data-bs-target="#q1" aria-expanded="false" aria-controls="q1"></i></div>
                                </button>
                                <div class="collapse mt-1" id="q1">
                                    <div class="card card-body bg-dark">
                                        This is a course selling and buying system. If you are a teacher you can
                                        upload courses and earn money. If you are a student you can buy and learn
                                        courses.
                                    </div>
                                </div>
                                <button type="button" class="btn btn-dark w-100 text-start mt-2"><span class="fs-6 position-absolute">How much does the course cost?</span>
                                    <div class="text-end"><i class="bi bi-plus-lg fs-6" data-bs-toggle="collapse" data-bs-target="#q2" aria-expanded="false" aria-controls="q2"></i></div>
                                </button>
                                <div class="collapse mt-1" id="q2">
                                    <div class="card card-body bg-dark">
                                        The cost of the course depends on the specific course you are interested in.
                                        Each course has its own price, which is determined by a number of factors,
                                        such as the length of the course, the level of expertise of the instructor,
                                        and the amount of resources included in the course. To view the price of a
                                        specific course, simply navigate to the course page on our website and the
                                        price will be displayed.
                                        We also occasionally offer discounts and promotions on our courses, so be
                                        sure to keep an eye out for any special deals.
                                    </div>
                                </div>
                                <button type="button" class="btn btn-dark w-100 text-start mt-2"><span class="fs-6 position-absolute">What are the other services?</span>
                                    <div class="text-end"><i class="bi bi-plus-lg fs-6" data-bs-toggle="collapse" data-bs-target="#q3" aria-expanded="false" aria-controls="q3"></i></div>
                                </button>
                                <div class="collapse mt-1" id="q3">
                                    <div class="card card-body bg-dark">
                                        In addition to social education networking, chat, and quick payment, there
                                        are a variety of other services that may be available on your platform. Some
                                        common additional services include personalized learning plans, course
                                        recommendations based on user interests, progress tracking, certificate and
                                        badge issuance upon completion of a course, and access to a community forum
                                        where users can connect with each other and share knowledge. Other potential
                                        services could include live online events such as webinars or Q&A sessions
                                        with industry experts, access to additional learning resources such as
                                        eBooks or online courses, and career services such as job search assistance
                                        or resume review. The specific services offered on your platform will depend
                                        on the goals and vision of your business,
                                        as well as the needs and preferences of your target audience.
                                    </div>
                                </div>
                                <button type="button" class="btn btn-dark w-100 text-start mt-2"><span class="fs-6 position-absolute">What is edu-social network?</span>
                                    <div class="text-end"><i class="bi bi-plus-lg fs-6" data-bs-toggle="collapse" data-bs-target="#q4" aria-expanded="false" aria-controls="q4"></i></div>
                                </button>
                                <div class="collapse mt-1" id="q4">
                                    <div class="card card-body bg-dark">
                                        An edu-social network is a platform that combines the social features of a
                                        social network with the educational components of an online learning
                                        platform. This type of network is designed to facilitate communication and
                                        collaboration among students, teachers, and other members of the education
                                        community. Like Facebook, an edu-social network allows users to create
                                        profiles, connect with friends, share information and updates, and
                                        participate in discussions. However, unlike Facebook, the focus of an
                                        edu-social network is on learning and education, rather than socializing and
                                        entertainment. Users can join groups based on their interests or academic
                                        subjects, participate in forums and chat rooms, and even attend virtual
                                        classes and lectures. The goal of an edu-social network is to create a
                                        community of learners who can support and learn from each other, regardless
                                        of their physical location or time zone. By leveraging the power of social
                                        networking and online learning,
                                        edu-social networks have the potential to transform the way we learn and
                                        share knowledge.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <?php include "footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
</body>

</html>