<?php
session_start();


require "connection.php";

$password = $_POST["p"];
$email = $_POST["e"];
$rememberme = $_POST["r"];

if (empty($password)) {
    echo ("Please enter your password");
} else if (strlen($password) < 6) {
    echo ("Password must have less than 6 characters");
} else {


    $rs = Database::search("SELECT * FROM `user` WHERE `email`='" . $email . "' AND `password`='" . $password . "'");
    $n = $rs->num_rows;

    if ($n == 1) {
        $lrs = Database::search("SELECT * FROM `user` WHERE `login_id`='1'");
        $ln = $lrs->num_rows;
        if ($ln == 1) {
            echo "sameuser";
        } else {
            $d = $rs->fetch_assoc();
            $_SESSION["u"] = $d;

            if ($rememberme == "true") {

                setcookie("email", $email, time() + (31104000));
                setcookie("password", $password, time() + (31104000));
            } else {

                setcookie("email", "", -1);
                setcookie("password", "", -1);
            }
            echo "success";
            
        }
    } else {
        echo "Something went wrong. please try again.";
    }
}




?>