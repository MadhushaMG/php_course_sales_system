<?php
session_start();
require "connection.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalToggleLabel">SEARCH AREA</h1>
                    <button type="button" class="btn-close" onclick="window.location.reload();"></button>
                </div>
                <div class="modal-body">
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <!-- Add a search bar -->
                            <div class="input-group mb-3">
                                <input type="text" id="modalSearchText" class="form-control" placeholder="Search..." onkeyup="performSearchInModal()" />
                            </div>
                            <div class="so">
                                <!-- Results will be displayed here -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12 col-12 position-fixed container-fluid" style="background-color: rgb(44, 6, 80); z-index: 2;">
        <div class="row ">
            <div class="col-lg-6 col-6 text-start">
                <nav class="navbar navbar-expand-lg bg-body-tertiary">
                    <div class="container-fluid text-uppercase">
                        <a class="navbar-brand  text-light fw-bold" href="index.php">STUDY-PACKS</a>
                        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                            <div class="navbar-nav ">
                                <a class="nav-link active text-light" aria-current="page" href="index.php"><span class="ih1">Home</span></a>
                                <a class="nav-link  text-light" href="subjects.php"><span class="ih2">Courses</span></a>
                                <a class="nav-link  text-light" href="#about"><span class="ih3">About</span></a>
                                <a class="nav-link  text-light" href="#"><span class="ih3">Contact us</span></a>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <div class="col-lg-6 col-6 text-end mt-2 d-lg-block d-none ">
                <div class="btn-group" role="group" aria-label="Basic outlined example">
                    <button type="button" class="btn">
                        <div class="input-group input-group-sm ">
                            <input type="text" class="form-control bg-light" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="Search..." id="searchText" onkeyup="myFunction()">
                            <span class="btn btn-light disabled" id="inputGroup-sizing-sm"><i class="bi bi-search"></i></span>
                        </div>
                    </button>
                    <button type="button" class="btn position-relative" onclick="window.location='addtocart.php'">
                        <i class="bi bi-basket text-light fs-5"></i>
                        <span class="position-absolute start-90 mt-2 translate-middle badge rounded-pill">
                            <?php
                            if (isset($_SESSION['u']["id"])) {
                                $crn_rs = Database::search("SELECT * FROM `cart` WHERE `user_id`='" . $_SESSION['u']["id"] . "' ");
                                $crn_num = $crn_rs->num_rows;
                                if ($crn_num == 0) {
                                    echo (" ");
                                } else {
                                    echo ($crn_num);
                                }
                            } else {
                                echo (" ");
                            }

                            ?>
                            <span class="visually-hidden">unread messages</span>
                        </span>
                    </button>

                    <?php
                    if (!(isset($_SESSION["u"]))) { ?>
                        <button type="button" class="btn text-light" onclick="window.location='stuSignUp.php'">Sign up</button>
                    <?php } else { ?>
                        <button type="button" class="btn text-light" onclick="window.location='dashboard.php'">HI, <?php
                                                                                                                    $nm = $_SESSION['u']["fname"];
                                                                                                                    $maxLength = 8; // Set your desired maximum length

                                                                                                                    if (strlen($nm) > $maxLength) {
                                                                                                                        $shortDescription = substr($nm, 0, $maxLength) . '...';
                                                                                                                        echo $shortDescription;
                                                                                                                    } else {
                                                                                                                        echo $nm;
                                                                                                                    }
                                                                                                                    ?></button>

                    <?php }

                    ?>

                </div>
            </div>
            <div class="col-lg-6 col-6 d-lg-none d-block text-end btn-group-sm mt-1">
                <button type="button" class="btn position-relative" onclick="window.location='addtocart.php'">
                    <i class="bi bi-basket text-light fs-5"></i>
                    <span class="position-absolute start-90 mt-2 translate-middle badge rounded-pill">
                        <?php
                        if (isset($_SESSION['u']["id"])) {
                            $crn_rs = Database::search("SELECT * FROM `cart` WHERE `user_id`='" . $_SESSION['u']["id"] . "' ");
                            $crn_num = $crn_rs->num_rows;
                            if ($crn_num == 0) {
                                echo (" ");
                            } else {
                                echo ($crn_num);
                            }
                        } else {
                            echo (" ");
                        }

                        ?>
                        <span class="visually-hidden">unread messages</span>
                    </span>
                </button>
                <button class="btn"><i class="bi bi-filter-square  text-light fs-3" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions"></i></button>
            </div>
        </div>
        <hr class="border border-2 border-light mt-0 mb-0" />
    </div>
    <!-- 
    header mobile view -->
    <div class="offcanvas offcanvas-start bg-dark" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions" aria-labelledby="offcanvasWithBothOptionsLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasScrollingLabel">
                <div class="text-start text-white fs-3 opacity-75 fw-bold"><span class=" fw-bold"></span>studyPack</div>
            </h5>

            <button type="button" class="btn-close text-bg-light" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="col-lg-12 col-12">
                <div class="row">
                    <div class="card">
                        sadty
                    </div>
                    <hr class="text-white mt-1  opacity-25 border border-3" />
                    <span class="text-white text-end " style="cursor: pointer;" onclick="LogOut();"><i class="bi bi-power"></i> LogOut</span>
                    <span class="text-white text-center mt-1 small opacity-75 ">Copyright © 2023 Trimana business solutions All Rights Reserved.</span>
                </div>
            </div>
        </div>
    </div>


    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>