<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courses | Studypacks</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
    <link rel="shortcut icon" href="./resources/systemImages/mortarboard.png" type="image/png">
</head>

<body>
    <!-- Preloader -->
    <div class="preloader" id="preloader">
        <img src="./resources/systemImages/loading.svg" alt="Preloader">
    </div>
    <?php include "indexHeader.php"; ?>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row">
            <div class="col-lg-3 col-12 mt-5">
                <div class="col-lg-12 col-12 h-100 bg-light mt-3">
                    <div class="row">
                        <span class="text-dark">Advance search</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-12 mt-5">
                <div class="col-lg-12 col-12 mt-3 subscroll container-fluid">
                    <div class="row">
                        <?php

                        $course = Database::search("SELECT * FROM `course`");
                        $coursen = $course->num_rows;
                        for ($y = 0; $y < $coursen; $y++) {
                            $cData = $course->fetch_assoc(); ?>

                            <div class="col-lg-3 col-12">
                                <div class="row-card-course">
                                    <div class="course-card">
                                        <div class="thumbnail">
                                            <div class="course-card-image">
                                                <a onclick="cartA(id='<?php echo $cData['id']; ?>');">
                                                    <img class="not-img img-res" src="https://assets.entrepreneur.com/content/3x2/2000/20141031174145-15-free-online-learning-sites.jpeg">
                                                </a>
                                            </div>
                                            <div class="caption">
                                                <div class="course-title">
                                                    <h3 class="course-title-heading">
                                                        <a class="not-a" href="/"> <?php echo $cData['name']; ?><br />

                                                            <small><small><?php echo $cData["lecturer_name"]; ?></small></small>
                                                        </a>

                                                    </h3>
                                                </div>
                                                <div class="course-fav-cost row">
                                                    <div class="course-rating-star">
                                                        <small>Rating</small>
                                                        <br>
                                                        <div class="course-rating">
                                                            <span><span> ☆</span><span class="active">
                                                                    ☆</span><span> ☆</span><span>
                                                                    ☆</span><span> ☆</span></span>
                                                        </div>
                                                    </div>
                                                    <div class="course-fav-price text-right">
                                                        <small>Price</small>
                                                        <div class="price-dollar">LKR.<?php echo $cData["price"]; ?></div>
                                                    </div>
                                                </div>
                                                <div class="course-card-foot">
                                                    <div class="course-card-foot-name main-name">
                                                        <i class="bi bi-cart-plus fs-4 text-dark" onclick="cartA(id='<?php echo $cData['id']; ?>');"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
     

    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>