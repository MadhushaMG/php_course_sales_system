<?php
require("connection.php");

$courseName = $_POST["cn"];
$sheduleDate = $_POST["sd"];
$sheduleTime = $_POST["st"];
$zoomLink = $_POST["zl"];
$sheudllerID = $_POST["sids"];
$sheduleType = $_POST["ctype"];

$timeForDatabase = $sheduleTime;
$today = new DateTime();  // Current date and time
$scheduleDateTime = new DateTime($sheduleDate . ' ' . $timeForDatabase);

if ($sheduleType == 'Online') {
    if (empty($courseName)) {
        echo ("Select course name");
    } else if (empty($sheduleDate)) {
        echo ("Warning! Please enter the date.");
    } else if (empty($sheduleTime)) {
        echo ("Warning! Please enter the time.");
    } else if (empty($zoomLink)) {
        echo ("Warning! Please enter the zoom link.");
    } else if ($today >= $scheduleDateTime) {
        echo ("Invalid date and time. Please select a future date and time.");
    } else {
        Database::iud("UPDATE `shedule` SET `date` = '" . $sheduleDate . "', `time` = '" . $sheduleTime . "', `status`='1', `course_id` = '" . $courseName . "', `link` = '" . $zoomLink . "', `shedule_type_id` = '1' WHERE `id` = '" . $sheudllerID . "'");
        echo ("done");
    }
} else {
    if (empty($courseName)) {
        echo ("Select course name");
    } else if (empty($zoomLink)) {
        echo ("Warning! Please enter the zoom link.");
    } else {
        Database::iud("UPDATE `shedule` SET `status`='1', `course_id` = '" . $courseName . "', `link` = '" . $zoomLink . "', `shedule_type_id` = '2' WHERE `id` = '" . $sheudllerID . "'");
        echo ("done");
    }
}
?>
