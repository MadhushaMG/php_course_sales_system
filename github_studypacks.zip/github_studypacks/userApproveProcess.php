<?php

require "connection.php";

if(isset($_GET["email"])){

    $user_email = $_GET["email"];

    $user_rs = Database::search("SELECT * FROM `user` WHERE `email`='".$user_email."' ");
    $user_num = $user_rs->num_rows;

    if($user_num == 1){
        $user_data = $user_rs->fetch_assoc();

            Database::iud("UPDATE `user_has_course` SET `payment_status`='1' WHERE `user_id`='". $user_data['id'] ."' ");
            echo("success");
        
    }else{
        echo("Cannot find the user. Please try again later.");
    }

}else{
    echo ("Something went wrong.");
} 
 