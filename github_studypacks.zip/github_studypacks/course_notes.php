<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sheduller</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row">
            <span class="text-start">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Notes</li>
                    </ol>
                </nav>
            </span>
            <div class="col-lg-12 col-12">
                <span class="fw-bold fs-6 text-uppercase "><i class="bi bi-caret-right-fill"></i>Notes panel</span>
                <div class="card mt-3  container-fluid  border border-0 bg-light">
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <div class="col-lg-6 col-12 mt-2 mb-2">
                                <span class="fs-6">Course name</span>
                                <select class="form-select" id="selectCoursen">
                                    <?php

                                    require "connection.php";

                                    $rs = Database::search("SELECT * FROM `course`");
                                    $n = $rs->num_rows;

                                    for ($x = 0; $x < $n; $x++) {
                                        $d = $rs->fetch_assoc();

                                    ?>
                                        <option value="<?php echo $d["id"]; ?>"><?php echo $d["name"]; ?></option>

                                    <?php

                                    }

                                    ?>
                                </select>
                            </div>
                            <div class="col-lg-6 col-12 mt-2 mb-3">
                                <span class="fs-6">Link</span>
                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="drive_Link" placeholder="Driver link">
                            </div>
                            <div class="col-lg-12 col-12 mt-2 mb-3">
                                <span class="fs-6">Description</span>
                                <textarea class="form-control" placeholder="Add description" id="dnotes"></textarea>
                            </div>

                            <div class="text-end text-uppercase"><span id="msgshedule" class="text-info fs-6"></span></div>
                            <div class="col-lg-12 col-12 mt-3 mb-1 text-end">
                                <button class="btn btn-danger mb-1" onclick="notesadd();" id="ssb">Save</button>
                                <div class="btn-group d-none" id="sab">
                                    <button class="btn btn-danger" onclick="updatesnotesData();" id="ssb">Update</button>
                                    <a href="#" class="btn btn-light" onclick="loadContent('sheduller.php');"><i class="bi bi-calendar-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-12 mt-3 container-fluid">
                <span class="fw-bold fs-6 text-uppercase"><i class="bi bi-caret-right-fill"></i>Preview area</span>
                <div class="maoscroll border border-0 bg-light container-fluid mt-2" style="height:50vh;">
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <?php

                            $d = new DateTime();
                            $tz = new DateTimeZone("Asia/Colombo");
                            $d->setTimezone($tz);
                            $dateNew = $d->format("Y-m-d H:i:s");


                            $crs_rs = Database::search("SELECT * FROM `course_notes`");
                            $crs_num = $crs_rs->num_rows;


                            for ($x = 0; $x < $crs_num; $x++) {
                                $cData = $crs_rs->fetch_assoc();
                                $course = Database::search("SELECT * FROM `course` WHERE `id` = '" . $cData['course_id'] . "'");
                                $courseData = $course->fetch_assoc();

                            ?>
                                <div class="col-lg-3 col-12 mt-2">
                                    <div class="card border border-0 shadow-sm" style="width: 100%;">
                                        <div class="card-body">
                                            <h6 class="card-title text-uppercase text-muted"><i class="bi bi-tag"></i> <?php echo $courseData["name"]; ?></h6>
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase"><i class="bi bi-person"></i> <?php echo $courseData["lecturer_name"]; ?></h6>
                                            <hr class="border border-3 border-dark" />
                                            <div class="col-lg-12 col-12">
                                                <div class="row">
                                                    <div class="btn-group">
                                                        <a href="<?php echo $cData["link"]; ?>" target="_blank" + class="btn btn-primary active" aria-current="page"><i class="bi bi-cloud-arrow-down-fill"></i></a>
                                                        <a href="#" class="btn btn-outline-primary active" onclick="updateShedule(<?php echo $cData['id']; ?>);"><i class="bi bi-arrow-repeat"></i></a>
                                                        <a href="#" class="btn btn-primary active" onclick="deleteShedule(<?php echo $cData['id']; ?>);"><i class="bi bi-trash"></i></a>
                                                    </div>
                                                    <div>
                                                    </div>

                                                </div>
                                            </div>

                                            </p>

                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>