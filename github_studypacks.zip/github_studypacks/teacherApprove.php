<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row ">
            <span class="text-start">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Approve</li>
                    </ol>
                </nav>
            </span>
            <div class="maoscroll" style="height:90vh;">
                <div class="col-lg-12 col-12">
                    <div class="row">
                        <?php
                        require "connection.php";

                        $d = new DateTime();
                        $tz = new DateTimeZone("Asia/Colombo");
                        $d->setTimezone($tz);
                        $dateNew = $d->format("Y-m-d H:i:s");


                        $bhm_rs = Database::search("SELECT * FROM `user_has_course` WHERE `payment_status`='0'");
                        $bhm_num = $bhm_rs->num_rows;

                        if ($bhm_num == 0) { ?>
                            <div class="col-lg-12 col-12" style="text-align: center;">
                                <div class="row">
                                    <div class="card border border-0 text-center" style="margin-top: 40vh;">
                                        <span>There are no students on the waiting list. <img src="resources/systemImages/Magnify-1.8s-200px.svg" style="width: 40px;" /></span>
                                    </div>
                                </div>
                            </div>

                            <?php } else {
                            for ($x = 0; $x < $bhm_num; $x++) {
                                $bhm_data = $bhm_rs->fetch_assoc();

                                $tcr_info_rs = Database::search("SELECT * FROM `user` WHERE `id`='" . $bhm_data['user_id'] . "'");
                                $tcr_info_data = $tcr_info_rs->fetch_assoc();
                                $crs_info_rs = Database::search("SELECT * FROM `course` WHERE `id`='" . $bhm_data['course_id'] . "'");
                                $crs_info_data = $crs_info_rs->fetch_assoc(); ?>



                                <div class="col-lg-6 col-12 mt-2">
                                    <div class="card" style="width: 100%;">
                                        <div class="card-body">
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase fw-bold fs-5">Course name : <?php echo ($crs_info_data['name']); ?></h6>
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase"><?php echo  $tcr_info_data["fname"]; ?> <?php echo  $tcr_info_data["lname"]; ?></h6>
                                            <hr />
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase small opacity-75 text-danger"><small class="small">Email : <input value="<?php echo  $tcr_info_data["email"]; ?>" disabled class="border border-0" /></small></h6>
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase small opacity-75 text-danger"><small class="small">User name : <input value="<?php echo  $tcr_info_data["mobile"]; ?>" disabled class="border border-0" /></small></h6>
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase small opacity-75 text-danger"><small class="small">Adress : <input value="<?php echo $tcr_info_data["email"]; ?>" disabled class="border border-0" /></small></h6>
                                            <h6 class="card-subtitle mb-2 text-muted text-uppercase small opacity-75 text-danger"><small class="small">University : <input value="<?php echo $tcr_info_data["email"]; ?>" disabled class="border border-0" /></small></h6>
                                            <button class="badge btn btn-danger">
                                                <a href="<?php echo $bhm_data["bank_r"]; ?>" download class="text-decoration-none text-white">
                                                    Download Bank Receipt <i class="bi bi-cloud-arrow-down-fill"></i>
                                                </a>
                                            </button>

                                            <hr class="border border-3 border-dark" />

                                            </p>
                                            <div class="col-lg-3 col-12 offset-lg-9">
                                                <div class="row">
                                                    <div class="btn-group btn-group-sm" role="group" aria-label="Small button group">
                                                        <img src="./resources/systemImages/ta.gif" /><button class="btn btn-danger " id="ua<?php echo  $tcr_info_data['email']; ?>" onclick="ApproveUser('<?php echo  $tcr_info_data['email']; ?>');">Approve</button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            <?php

                            } ?>


                        <?php

                        }

                        ?>


                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>