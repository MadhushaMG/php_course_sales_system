<?php

session_start();

require "connection.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sheduller</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row">
            <span class="text-start">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Courses</li>
                    </ol>
                </nav>
            </span>
            <div class="col-lg-12 col-12">
                <div class="row maoscroll" style="height:90vh;">
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <?php
                            $st_rs = Database::search("SELECT * FROM `user_has_course` WHERE `user_id` = '" . $_SESSION['u']["id"] . "'");
                            $strows = $st_rs->num_rows;
                            if ($strows == 0) { ?>
                                <div class="col-lg-12 col-12 container-fluid">
                                    <div class="row">
                                        <div class="card border border-0 text-center" style="margin-top: 40vh;">
                                            <span>Not registered for courses.<img src="resources/systemImages/Magnify-1.8s-200px.svg" style="width: 40px;" /></span>
                                        </div>
                                    </div>

                                </div>
                                <?php } else {
                                $stData = $st_rs->fetch_assoc();
                                $crs_rs = Database::search("SELECT * FROM `shedule` WHERE `course_id` = '" . $_GET['id'] . "' ORDER BY `date` ASC");
                                $crsrw = $crs_rs->num_rows;
                                for ($y = 0; $y < $crsrw; $y++) {
                                    $cData = $crs_rs->fetch_assoc();
                                    $coursemarks = Database::search("SELECT * FROM `course_marks` WHERE `shedule_id` = '" . $cData['id'] . "' AND `status` = '1'");
                                    $coursemarks_n = $coursemarks->num_rows;
                                    $course = Database::search("SELECT * FROM `course` WHERE `id` = '" . $cData['course_id'] . "'");
                                    $courseData = $course->fetch_assoc();
                                ?>
                                    <div class="col-lg-3 col-12 mt-2">
                                        <div class="card" style="width: 100%;">
                                            <div class="card-header">
                                                <?php
                                                if (empty($cData['date'])) { ?>
                                                    <span class="badge text-bg-primary">Recorded</span>
                                                <?php } else { ?>
                                                    <span class="badge text-bg-primary"><?php echo  $cData['date']; ?></span>
                                                <?php }
                                                if ($coursemarks_n == 1) { ?>
                                                    <span class="badge text-bg-danger">Wathed</span>
                                                <?php } else {
                                                }
                                                ?>

                                            </div>
                                            <div class="card-body">
                                                <h6 class="card-title text-uppercase text-muted"><i class="bi bi-tag"></i> <?php echo $courseData["name"]; ?></h6>
                                                <h6 class="card-subtitle mb-2 text-muted text-uppercase"><i class="bi bi-person"></i> <?php echo $courseData["lecturer_name"]; ?></h6>
                                                <h6 class="card-subtitle mb-2 text-muted text-uppercase">
                                                    <?php
                                                    if (empty($cData['time'])) { ?>
                                                        <i class="bi bi-alarm"></i> Anytime
                                                    <?php } else { ?>
                                                        <i class="bi bi-alarm"></i> <?php echo  $cData['time']; ?>
                                                    <?php }

                                                    ?>
                                                </h6>
                                                <h6 class="card-subtitle mb-2 text-muted text-uppercase">
                                                    <?php
                                                    if ($cData['shedule_type_id'] == 1) { ?>
                                                        <i class="bi bi-wifi"></i> <?php echo "Online"; ?>
                                                    <?php } else { ?>
                                                        <i class="bi bi-wifi-off"></i> <?php echo "Offline"; ?>
                                                    <?php }

                                                    ?>
                                                    <hr class="border border-3 border-dark" />
                                                    <div class="col-lg-12 col-12">
                                                        <div class="row">
                                                            <div class="btn-group">
                                                                <a href="<?php echo $cData["link"]; ?>" target="_blank" class="btn btn-dark active opacity-75" aria-current="page" onclick="clickscore(id1='<?php echo $cData['id']; ?>', id2='<?php echo $stData['id']; ?>');">Click here to join</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </p>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                }
                            }
                            ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>