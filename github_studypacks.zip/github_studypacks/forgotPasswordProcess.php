<?php

require "connection.php";

require "SMTP.php";
require "PHPMailer.php";
require "Exception.php";
session_start();
use PHPMailer\PHPMailer\PHPMailer;

if(isset($_GET["e"])){

    $email = $_GET["e"];

    $rs = Database::search("SELECT * FROM `user` WHERE `email`='".$email."'");
    $n = $rs->num_rows;

    if($n == 1){

        $code = uniqid();

        Database::iud("UPDATE `user` SET `otp`='".$code."' WHERE `email`='".$email."'");
        $_SESSION['useremail'] = $email;
        $mail = new PHPMailer;
            $mail->IsSMTP();
            $mail->Host = 'mail.studypacks.lk';
            $mail->SMTPAuth = true;
            $mail->Username = 'noreply@studypacks.lk';
            $mail->Password = 'ljmP5Vx9SYS2';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->setFrom('noreply@studypacks.lk', 'Reset Password');
            $mail->addReplyTo('noreply@studypacks.lk', 'Reset Password');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = ' noreply@studypacks.lk';
            $bodyContent = '
            
            
             
        <!DOCTYPE html>
        <html lang="en">
        
        <head>
            <title>Email verify</title>
        
            <link rel="stylesheet" href="bootstrap.css" />
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
            <link rel="stylesheet" href="style.css" />
        </head>
        
        <body>
            <div class="col-lg-12 col-12 container-fluid">
                <div class="row">
                    <div class=" col-lg-10 offset-1 col-12 emb ">
                        <h1 class=" fw-bold">STUDY-PACKS</h1><br />
                        <h2 class=" fw-bold">RESET PASSWORD</h2>
                        <br />
                        <hr />
                        <h5>Good day and welcome to STUDY-PACKS. Forgot your account password? Then cancel your old password and reset a new password and refer to your account. 
                        Therefore, you must ensure that the email address is yours. For that, enter this verification code into the system and access the system with your new password. 
                        good day<br/><br/>
                            
                            <div style="margin-left: 40%; background-color:red; width:25%; text-align:center; font-weight: bold;">'.$code.'</div>
        
        
                        </h5>
                            <br/><br/><br/>
                            <br/><br/><br/>
                            <br/><br/><br/>
                            <h6 style="text-align: center;">PLEASE NOTE THAT THIS IS A SYSTEM-GENERATED EMAIL. <br/><small class=" text-uppercase">Copyright © 2023 CODARA All Rights Reserved</small></h6>
                    </div>
                </div>
            </div>
        </body>
        
        </html>
        
            
            ';
            $mail->Body    = $bodyContent;
            
            if (!$mail->send()) {
                echo 'Verification code sending failed';
            } else {
                echo 'Success';
            }

    }else{
        echo ("Invalid Email address");
    }

}else{
    echo "Something went wrong. Please try again!";
}

?>