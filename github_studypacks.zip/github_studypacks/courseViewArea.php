<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>lessonView</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row">

            <div class="col-lg-9 col-12 border border-3 border-dark border-start-0 border-top-0 border-bottom-0" id="lessonViewMain">
                <div class="col-lg-12 col-12 mt-2">
                    <div class="row">
                        <iframe width="560" height="515" src="" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-lg-12 col-12 container-fluid">
                    <div class="row">
                        <span class=" fw-bold fs-5 mt-2 mb-1">Note for your course content</span>
                        <?php
                            require "connection.php";
                            $course_id = 3;
                            $course = Database::search("SELECT * FROM `course` WHERE `id`='" . $course_id . "'");
                            $courseData = $course->fetch_assoc();
                           
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-12 lessonView mt-2">
                <div class="col-lg-12 col-12 text-center">
                    <div class="row">
                        <span class="fw-bold fs-5 text-uppercase">Your lessons</span><br/><hr/>
                    </div>
                </div>
                <ul class="list-group list-group-flush">
                    <?php
                    $course_id = $_GET['coursen_id'];
                    $lessons = Database::search("SELECT * FROM `shedule` WHERE `course_id`='" . $course_id . "'");
                    for ($x = 0; $x < $lessons->num_rows; $x++) {
                        $lessonsData = $lessons->fetch_assoc();
                        $videoId = $lessonsData["videos_path"];
                        $videoUrl = "https://www.youtube.com/embed/" . $videoId;
                    ?>
                        <li class="list-group-item btn btn-dark text-start" onclick="changeVideo('<?php echo $videoUrl ?>')" style="cursor:pointer;">
                            Lesson <?php echo ($x + 1); ?>: <?php echo ($lessonsData["topic"]);  ?>
                        </li>
                    <?php }
                    ?>
                </ul>
            </div>
        </div>
    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>