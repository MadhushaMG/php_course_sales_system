<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ReportsView</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row">
            <div class="col-lg-6 col-12">
                <span class="text-start">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Reports</li>
                        </ol>
                    </nav>
                </span>
            </div>
            <div class="col-lg-12 col-12">
                <div class="row">
                    <?php
                    require "connection.php";
                    $report_row = Database::search("SELECT * FROM `report` ORDER BY `id` DESC");
                    $report_num = $report_row->num_rows;
                    for ($x = 0; $x < $report_num; $x++) {
                        $report_data = $report_row->fetch_assoc();

                        $reportUser = Database::search("SELECT * FROM `user` WHERE `id` = '" . $report_data["user_id"] . "'");
                        $reportUser_data = $reportUser->fetch_assoc(); ?>


                        <div class="#">
                            <h3><i class="bi bi-gear-wide"></i></h3>
                            <div class="chatBox" style="margin-top: 0%;"><?php echo ($report_data["content"]); ?><br/><hr/>
                                <span class="text-white opacity-50">Name : <?php echo ($reportUser_data["fname"]);?> <?php echo($reportUser_data["lname"]);  ?></span><br>
                                <span class="text-white opacity-50">Referred time : <?php echo($report_data["date"]); ?></span>
                            </div>
                        </div>

                    <?php }


                    ?>
                </div>
            </div>
        </div>
    </div>

    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>