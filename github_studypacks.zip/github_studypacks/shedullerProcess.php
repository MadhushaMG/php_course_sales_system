<?php
require("connection.php");

$courseName = $_POST["cn"];
$sheduleDate = $_POST["sd"];
$sheduleTime = $_POST["st"];
$zoomLink = $_POST["zl"];
$sheduleType = $_POST["ctype"];

$timeForDatabase = $sheduleTime;
$today = date("Y-m-d H:i");
$scheduleDateTime = new DateTime($sheduleDate . ' ' . $timeForDatabase);



if ($sheduleType == 'Online') {
    if (empty($courseName)) {
        echo ("Select course name");
    } else if (empty($sheduleDate)) {
        echo ("Warning! Please enter the date.");
    } else if (empty($sheduleTime)) {
        echo ("Warning! Please enter the time.");
    } else if (empty($zoomLink)) {
        echo ("Warning! Please enter the zoom link.");
    } else if ($today >= $scheduleDateTime) {
        echo ("Invalid date and time. Please select a future date and time.");
    } else {
        Database::iud("INSERT INTO `shedule` (`date`,`time`,`status`,`course_id`,`link`,`shedule_type_id`) VALUES ('" . $sheduleDate . "','" . $timeForDatabase . "','1','" . $courseName . "','" . $zoomLink . "','1')");
        echo ("done");
    }
} else {
    if (empty($courseName)) {
        echo ("Select course name");
    } else if (empty($zoomLink)) {
        echo ("Warning! Please enter the zoom link.");
    } else {
        Database::iud("INSERT INTO `shedule` (`status`,`course_id`,`link`,`shedule_type_id`) VALUES ('1','" . $courseName . "','" . $zoomLink . "','2')");
        echo("done");
    }
    
}
