<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AddToCart</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
    <link rel="shortcut icon" href="./resources/systemImages/mortarboard.png" type="image/png">
</head>

<body>
    <!-- Preloader -->
    <div class="preloader" id="preloader">
        <img src="./resources/systemImages/loading.svg" alt="Preloader">
    </div>
    <?php require "indexHeader.php"; ?>
    <div class="col-lg-6 col-12">
        <span class="text-start">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="$">courses</li>
                    <li class="breadcrumb-item active" aria-current="page">Add to cart</li>
                </ol>
            </nav>
        </span>
    </div>
    <?php
    if (isset($_SESSION['u']['id'])) {

    ?>
        <div class="col-lg-12 col-12 container-fluid">
            <div class="row">
                <div class="col-lg-7 col-12 container-fluid ">
                    <table class="table mt-5">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">Status</th>
                                <th scope="col">Course name</th>
                                <th scope="col">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $cartItems = Database::search("SELECT * FROM `cart` WHERE `user_id`= '" . $_SESSION['u']["id"] . "' AND `status` = '1'");
                            $tp = 0.0;
                            $cartrs = $cartItems->num_rows;
                            for ($x = 0; $x < $cartrs; $x++) {
                                $cartItemsData = $cartItems->fetch_assoc();

                                $courseItems = Database::search("SELECT * FROM `course` WHERE `id`= '" . $cartItemsData["course_id"] . "'");
                                $courseData =  $courseItems->fetch_assoc();
                                $allCourse = Database::search("SELECT * FROM `course`");
                                $allCourseData = $allCourse->fetch_assoc();
                                if (isset($courseData["price"])) {
                                    $tp += floatval($courseData["price"]);
                                } else {
                                    error_log("Price not set in \$courseData");
                                    // You can also echo or log more details for debugging
                                }
                            ?>
                                <tr>
                                    <td scope="row"><span class="badge" style="cursor: pointer;" onclick="cartR('<?php echo $cartItemsData['id']; ?>');"><i class="bi bi-x-circle-fill text-dark fs-6"></i></span>
                                    <td><?php echo ($courseData["name"]); ?></td>
                                    </td>
                                    <td>LKR.<?php echo ($courseData["price"]);  ?>.00</td>

                                </tr>
                            <?php }

                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="col-lg-4 col-12 card container-fluid mt-5 shadow-lg border border-0">
                    <div class="row">
                        <div class="col-lg-6 col-6 mt-2">
                            <span class="text-end fs-5 fw-bold">Total : LKR.<?php echo ($tp); ?>.00 </span><br />
                        </div>
                        <div class="col-lg-6 col-6 text-end mt-1 mb-1 container-fluid">
                            <?php
                            if ($cartrs == 0) { ?>
                                <a href="subjects.php">
                                    <div class="btn btn-danger">Add a course to cart</div>
                                </a>

                            <?php } else { ?>
                                <div class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Buy now</div>
                            <?php }
                            ?>
                        </div>
                        <hr />
                        <span class="mt-1 fw-bold">USER DETAILS :</span>
                        <div class="container-fluid mb-2">
                            USER NAME : <?php echo $_SESSION['u']['fname'] . ' ' . $_SESSION['u']['lname']; ?><br />
                            EMAIL : <?php echo $_SESSION['u']['email']; ?> <br />
                            PAYMENT METHOD : Bank deposit(Default) <br />
                        </div>
                        <hr />
                        <span class="mt-1 fw-bold">BANK DEPOSIT DETAILS :</span>
                        <span>Test details</span>
                        <span class="text-danger small mt-5 mb-5"><span class="small">The total cost of the courses you purchase is as follows.
                                You have the opportunity to study your course by settling the amount in the payment method of your choice.</span></span>
                      
                    </div>
                </div>
                <hr class="mt-3"/>
               
            </div>
        </div>
    <?php } else {
        echo ('<div class="col-lg-12 col-12 container-fluid">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-12 text-center" style="margin-top: 15%;">
                You are not logged in. <a href="index.php">Please log in </a>
            </div>
        </div>
    </div>');
    }
    ?>
    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">LKR.<?php echo ($tp);  ?>.00 | STUDY-PACKS</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="col-lg-12 col-12">
                        <div class="row">

                            <span class="small">You pay the above amount to the account and enter the receipt and upload it.</span>
                            <input type="file" class="form-control border border-0 bg-dark text-light bg-opacity-75" aria-describedby="basic-addon1">

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Buy</button>
                </div>
            </div>
        </div>
    </div>
    <div style="margin-top: 20vh;">
        <?php include "footer.php"; ?>
    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>