<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password reset</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body class="bg">
    <div class="container-fluid">
        <div class="col-lg-12 col-12">
            <div class="row ">
                <div class="col-lg-12 col-12">
                    <div class="row">
                        <div class="col-lg-6 col-6 text-start">
                            <h4 class="text-info fw-bold mt-2">STUDY-PACKS</h4>
                        </div>
                        <div class="col-lg-6 col-6 text-end mt-2">
                            <a href="index.php"><button type="button" class="btn btn-danger btn-sm fw-bold">Sign In</button></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 "></div>
                <div class="col-lg-4 col-12" style="margin-top:2%;">
                    <?php
                    if (!isset($_SESSION['useremail'])) {
                        header("Location:index.php");
                        exit();
                    } else {
                        $email =  $_SESSION['useremail'];
                    }
                    ?>

                    <span class="fs-3 text-white fw-bold">Reset your password</span><br />
                    <span class="fs-6 text-white ">A OTP code has been sent to your email address. Please check your email.</span><br />
                    <hr class="border border-info border-2 opacity-50">
                    <span class="text-white fs-6 ">Email</span><br />
                    <input  class="bcol-lg-12 col-12 form-control"  id="emailset" value="<?php echo ($email); ?>" readonly /><br />

                    <span class="text-white fs-6 ">Enter your new password</span><br />
                    <div class="input-group input-group-md mb-3">
                        <input type="password" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="npi" />
                        <button type="btn" class="btn btn-danger" onclick="showPassword2();"><i class="bi bi-eye-slash" id="e2"></i></button>
                    </div>
                    <span class="text-white fs-6 ">Enter your new password again</span><br />
                    <div class="input-group input-group-md mb-3">
                        <input type="password" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="rnp" />
                        <button type="btn" class="btn btn-danger" onclick="showPassword3();"><i class="bi bi-eye-slash" id="e3"></i></button>
                    </div>
                    <span class="text-white fs-6 ">Enter your OTP code </span><br />
                    <div class="input-group input-group-md mb-3">
                        <input type="password" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="vc" />
                        <button type="btn" class="btn btn-danger" onclick="showPassword4();"><i class="bi bi-eye-slash" id="e4"></i></button>
                    </div>
                    <div class="text-end text-uppercase"><span id="msg3" class="text-info fs-6"></span></div>
                    <div class="col-lg-12 col-12">
                        <button class="btn btn-danger mt-2 w-100 mb-2" type="button" onclick="resetpw();">Reset Password</button>

                    </div>
                </div>
                <div class="col-lg-4 "></div>
            </div>
        </div>
    </div>


    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>