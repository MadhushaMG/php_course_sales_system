<?php

if (isset($_SESSION["u"])) {


  $userheader_rs = Database::search("SELECT * FROM `user` WHERE `email`='" . $_SESSION['u']["email"] . "'");
  $userheader_data = $userheader_rs->fetch_assoc();


?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nav</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
  </head>

  <body>
    <div class="col-lg-12 col-12 bg-dark d-lg-block d-none">
      <div class="row">
        <div class="col-lg-6 col-6 text-start fw-bold fs-5 text-white d-none" id="hmenu">
          <span><span onclick="menubar();"><i class="bi bi-list"></span></i>STUDY-PACKS</span>
        </div>
        <div class="col-lg-12 col-6 text-end mt-1" id="bgcon">
          <div class="col-lg-12 col-12 text-end btn-group-sm">
            <button class="btn btn-dark" onclick="window.location.href='dashboard.php';">
              <i class="bi bi-calendar3 small"></i>
              <?php
              echo date('Y-m-d');
              ?>
            </button>
            <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#exampleModal">
              <i class="bi bi-bootstrap-reboot"></i>
            </button>
            <button class="btn btn-dark" onclick="window.location.href='index.php';">
              <i class="bi bi-house-fill"></i>
            </button>
            <button class="btn btn-dark" onclick="window.location.href='subjects.php';">
              <i class="bi bi-cart-plus-fill"></i>
            </button>
            <?php
            if ($_SESSION['u']['user_type_id'] == 1) { ?>
              <button type="button" class="btn btn-dark position-relative" onclick="loadContent('adminReportsView.php');">
                <i class="bi bi-bell-fill"></i>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  <?php
                  $aa_rs = Database::search("SELECT * FROM `user_has_course` WHERE `payment_status`='0'");
                  $aa_num = $aa_rs->num_rows;
                  echo ($aa_num);
                  ?>

                  <span class="visually-hidden">unread messages</span>
                </span>
              </button>
            <?php } else {
            }

            ?>
            <div class="btn-group text-end" role="group" aria-label="Basic example">
              <span class="text-white">
                <div class="dropdown">
                  <span data-bs-toggle="dropdown" aria-expanded="false">
                    | HI, <?php
                          if ($userheader_data["user_type_id"] == 1) {
                            echo ("Admin");
                          } else if ($userheader_data["user_type_id"] == 2) {
                            echo ("Student");
                          } else {
                            include "sessionEView.php";
                          }
                          ?>
                  </span>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" onclick="LogOut();">LogOut <i class="bi bi-box-arrow-left"></i></a>
                    </li>
                  </ul>
                </div>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    <div class="col-lg-12 col-12 d-lg-none d-block">
      <div class="row">
        <div class="bg-dark">
          <div class="col-12">
            <div class="row">
              <div class="col-6">
                <div class="text-start fw-bold fs-5 " id="hmenu">
                  <span class="text-light">STUDY-PACKS</span>
                </div>
              </div>
              <div class="col-6 text-white text-end">
                <i class="bi bi-justify fs-5" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling"></i>
              </div>
            </div>
          </div>
          <div class="col-12">
            <hr class="mt-0 mb-0 text-light" />
            <div class="col-lg-12 col-12 text-center btn-group-sm">
              <button class="btn btn-dark" onclick="window.location.href='dashboard.php';">
                <i class="bi bi-calendar3 small"></i>
                <?php
                echo date('Y-m-d');
                ?>
              </button>
              <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <i class="bi bi-bootstrap-reboot"></i>
              </button>
              <button class="btn btn-dark" onclick="window.location.href='index.php';">
                <i class="bi bi-house-fill"></i>
              </button>
              <button class="btn btn-dark" onclick="window.location.href='subjects.php';">
                <i class="bi bi-cart-plus-fill"></i>
              </button>
              <?php
              if ($_SESSION['u']['user_type_id'] == 1) { ?>
                <button type="button" class="btn btn-dark position-relative" onclick="loadContent('adminReportsView.php');">
                  <i class="bi bi-bell-fill"></i>
                  <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php
                    $aa_rs = Database::search("SELECT * FROM `user_has_course` WHERE `payment_status`='0'");
                    $aa_num = $aa_rs->num_rows;
                    echo ($aa_num);
                    ?>

                    <span class="visually-hidden">unread messages</span>
                  </span>
                </button>
              <?php } else {
              }

              ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="offcanvas offcanvas-start bg-dark" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasScrollingLabel">
          <div class="text-start text-white fs-3 opacity-75 fw-bold"><span class=" fw-bold"></span>STUDY-PACKS</div>
        </h5>

        <button type="button" class="btn-close text-bg-light" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <div class="col-lg-12 col-12">
          <div class="row">
            <?php
            $u_rs = Database::search("SELECT * FROM `user` WHERE `id`='" . $_SESSION['u']["id"] . "'");
            $u_data = $u_rs->fetch_assoc();

            if (empty($u_data["profile_img"])) {

            ?>
              <span class="text-center"><img src="resources/systemImages/user.png" class="rounded-circle" style="width: 100px;" /><br />
              <?php
            } else {

              ?>

                <span class="text-center"><img src="<?php echo $u_data["profile_img"]; ?>" class="rounded-circle" style="width: 100px; height: 100px;" /><br />

                <?php
              }
                ?>

                <span class="fw-bold  text-white fs-6 text-uppercase"><?php echo ($user_data["fname"]); ?>_<?php echo ($user_data["lname"]); ?></span><br />
                <small><small class="fw-bold text-white opacity-50"><?php echo ($user_data["email"]); ?> <i class="bi bi-patch-check"></i></small></small>
                <hr class=" text-white" />
                </span>
                <div class="col-lg-12 col-12">
                  <div class="row">
                    <?php
                    $userTypeID = $user_data["user_type_id"];
                    if ($userTypeID == 1) { ?>
                      <span class="mt-2 text-white" onclick="loadContent('adminHome.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-house"></i> Home</span>
                      <span class="mt-4 text-white" onclick="loadContent('adminManageAO.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-people"></i> Manage Students</span>
                      <span class="mt-4 text-white" onclick="loadContent('adminManageCourses.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-mortarboard"></i> Manage course</span>
                      <span class="mt-4 text-white" onclick="loadContent('sheduller.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-command"></i> Zoom sheduler</span>
                      <span class="mt-4 text-white" data-bs-toggle="modal" data-bs-target="#sn" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-card-heading"></i> Special Notice</span>
                      <span class="mt-4 text-white" onclick="loadContent('adminReportsView.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-flag"></i> Reports</span>
                      <span class="mt-4 text-white" onclick="loadContent('updateProfile.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-gear"></i> Manage Profile </span>
                    <?php } elseif ($userTypeID == 2) { ?>
                      <span class="mt-2 text-white" onclick="loadContent('adminHome.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-house"></i> Home</span>
                      <span class="mt-4 text-white" onclick="loadContent('shedullerPriveiw.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-people"></i> Active TimeTable</span>
                      <span class="mt-4 text-white" onclick="loadContent('updateProfile.php')" style="cursor: pointer;" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-gear"></i> Manage Profile </span>
                    <?php }
                    ?>
                  </div>
                </div>
                <hr class="text-white mt-1  opacity-25 border border-3" />
                <span class="text-white text-end " style="cursor: pointer;" onclick="LogOut();"><i class="bi bi-power"></i> LogOut</span>
                <span class="text-white text-center mt-1 small opacity-75 ">Copyright © 2023 Trimana business solutions All Rights Reserved.</span>
          </div>
        </div>
      </div>
    </div>

    <script src="script.js"></script>
  </body>

  </html>

<?php

} else {
  include "sessionEView.php";
}

?>