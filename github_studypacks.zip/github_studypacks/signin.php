<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In | STUDY-PACKS</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body class="bgn">
    <div class="container-fluid">
        <div class="col-lg-12 col-12">
            <div class="row ">
                <div class="col-lg-12 col-12">
                    <div class="row">
                        <div class="col-lg-6 col-6 text-start">
                            <h4 class="text-info fw-bold mt-2">STUDY-PACKS</h4>
                        </div>
                        <div class="col-lg-6 col-6 text-end mt-2">
                            <a href="index.php"><button type="button" class="btn btn-danger btn-sm fw-bold">Sign In</button></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 "></div>
                <div class="col-lg-4 col-12" style="margin-top:10%;">
                    <?php
                    if (!isset($_SESSION['useremail'])) {
                        header("Location:index.php");
                        exit();
                    } else {
                        $email =  $_SESSION['useremail'];
                    }
                    ?>
                    <div>
                        <span class="fs-3 text-white fw-bold">Welcome back!</span><br />
                        <span class="fs-4 text-white fw-bold">Joining STUDY-PACKS is easy.</span><br />
                        <span class="fs-5 text-white ">Enter your password and you can learn quickly.</span><br />
                        <hr class="border border-info border-2 opacity-50">
                        <span class="text-white fs-6 ">Email</span><br />
                        <input class="signInmail" id="emailset" value="<?php echo ($email); ?>" readonly /><br />
                        <?php
                        $password = "";

                        if (isset($_COOKIE["password"])) {
                            $password = $_COOKIE["password"];
                        }

                        ?>

                        <span class="text-white fs-6 ">Password</span><br />
                        <div class="input-group input-group-md mb-3">
                            <input type="password" class="form-control" id="signInpid" value="<?php echo $password; ?>" />
                            <button class="btn btn-danger" type="button" id="npb" onclick="showPassword1();"><i id="e1" class="bi bi-eye-slash-fill"></i></button>
                        </div>
                        <div class="text-end text-uppercase"><span id="msg3" class="text-info fs-6"></span></div>
                        <div class="col-lg-12 col-12">
                            <div class="row">
                                <div class="col-lg-6 col-6 text-start">
                                    <span class="fs-6" onclick="forgotPassword();"><a href="#" class="text-white">Forgot your password?</a></span><br />
                                </div>
                                <div class="col-lg-6 col-6 ">
                                    <div class="form-check form-check-reverse">
                                        <input class="form-check-input" type="checkbox" id="rememberme">
                                        <label class="form-check-label text-white" for="reverseCheck1">
                                            Remember me
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <button class="btn btn-danger mt-2 w-100" type="button" onclick="signIn();">Sign In</button>

                        </div>
                    </div>
                    <div class="col-lg-4 "></div>
                </div>
            </div>
        </div>



        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
</body>

</html>