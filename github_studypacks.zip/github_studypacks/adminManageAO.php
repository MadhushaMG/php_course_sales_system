<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row ">
            <span class="text-start">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Manage Students</li>
                    </ol>
                </nav>
            </span>
            <div class="maoscroll" style="height:90vh;">
                <div class="col-lg-12 col-12">
                    <div class="row">
                        <?php
                        require "connection.php";
                        $d = new DateTime();
                        $tz = new DateTimeZone("Asia/Colombo");
                        $d->setTimezone($tz);
                        $dateNew = $d->format("Y-m-d H:i:s");


                        $ao_rs = Database::search("SELECT * FROM `user` WHERE `user_type_id`='2'");
                        $ao_num = $ao_rs->num_rows;

                        for ($x = 0; $x < $ao_num; $x++) {
                            $ao_data = $ao_rs->fetch_assoc();
                        ?>
                            <div class="col-lg-3 col-12 mt-2">
                                <div class="card" style="width: 100%;">
                                    <div class="card-body">
                                        <div class="row">
                                            <h5 class="card-title fw-bold"><?php echo ($ao_data['fname']); ?></h5>
                                            <div class="rounded-circle position-absolute end-0" style="width: 35px; height: 35px; margin-right: 15px;">
                                                <?php
                                                if (empty($ao_data["profile_img"])) {
                                                    echo '<img src="./resources/systemImages/teacherPanel.png" style="width: 35px; height: 35px; border-radius: 50%; background-color: rgb(128, 128, 128, 0.5);"/>';
                                                } else {
                                                    echo '<img src="' . $ao_data["profile_img"] . '" style="width: 35px; height: 35px; border-radius: 50%; background-color: rgb(128, 128, 128, 0.5); "/>';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <h6 class="card-subtitle mb-2 text-muted text-uppercase small opacity-75 text-danger mt-2"><small class="small"><input class="w-100 border border-0" value="Name : <?php echo $ao_data["fname"]; ?> <?php echo $ao_data["lname"]; ?>" disabled /></small></h6>
                                        <h6 class="card-subtitle mb-2 text-muted text-uppercase small opacity-75 text-danger"><small class="small"><input class="w-100 border border-0" value="User name : <?php echo $ao_data["mobile"]; ?>" disabled /></small></h6>
                                        <h6 class="card-subtitle text-muted text-uppercase small opacity-75 text-danger"><small class="small"><input class="w-100 border border-0" value="RegDate : <?php echo $ao_data["email"]; ?>" disabled /></small></h6>
                                        <hr class="border border-3 border-dark mt-2" />
                                        <div class="col-lg-12 col-12 ">
                                            <div class="row">
                                                <div class="btn-group btn-group-sm" role="group" aria-label="Small button group">
                                                    <?php

                                                    if ($ao_data["status"] == 1) {
                                                    ?>
                                                        <button class="btn btn-danger" id="ub<?php echo $ao_data['email']; ?>" onclick="blockUser('<?php echo $ao_data['email']; ?>');">Block</button>
                                                    <?php

                                                    } else {
                                                    ?>
                                                        <button class="btn btn-success" id="ub<?php echo $ao_data['email']; ?>" onclick="blockUser('<?php echo $ao_data['email']; ?>');">Unblock</button>
                                                    <?php

                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php

                        }

                        ?>
                        <div class="col-lg-3 col-12 mt-2">
                            <div class="card" style="width: 100%;   height:26vh;">
                                <div class="card-body mx-auto">
                                    <h1 class="mt-5"><i class="bi bi-plus-square-fill" data-bs-toggle="modal" data-bs-target="#exampleModalhj"></i></h1>
                                </div>
                            </div>
                        </div>


                        <!-- Modal -->
                        <div class="modal fade" id="exampleModalhj" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">

                                <!-- addAO1 -->


                                <div class="modal-content d-block" id="aont1">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Add new student</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="col-lg-12 col-12">
                                            <div class="row">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" placeholder="First name" aria-label="Recipient's username" aria-describedby="button-addon2" id="AOfname">
                                                    <input type="text" class="form-control" placeholder="Last name" aria-label="Recipient's username" aria-describedby="button-addon2" id="AOlname">
                                                </div>
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" placeholder="Email" aria-label="Recipient's username" aria-describedby="button-addon2" id="AOemail">
                                                </div>
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" placeholder="Phone number" aria-label="Recipient's username" aria-describedby="button-addon2" id="AOnum">
                                                </div><hr/>
                                                <div class="col-lg-12 col-12 mt-0">
                                                    <span class="fs-6">Course name</span><br/>

                                                    <h6 id="addcourses" class="mt-1 text-dark opacity-50 fw-bold"></h6>
                                                    <div class="input-group mb-3">
                                                        <select class="form-select" id="selectCoursen">
                                                            <?php

                                                            $rs = Database::search("SELECT * FROM `course`");
                                                            $n = $rs->num_rows;

                                                            for ($x = 0; $x < $n; $x++) {
                                                                $d = $rs->fetch_assoc();

                                                            ?>
                                                                <option value="<?php echo $d['id'] . '|' . htmlspecialchars($d['name']); ?>"><?php echo $d['name']; ?></option>

                                                            <?php

                                                            }

                                                            ?>
                                                        </select>
                                                        <span class="btn btn-dark" onclick="courseadd();">Add</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <span id="aomsg" class="text-end text-danger fw-bold"></span>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary " onclick="AOnextbtn();">Sent invitation and save</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>