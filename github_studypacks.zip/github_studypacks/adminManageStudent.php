<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row ">
            <span class="text-start">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Manage Students</li>
                    </ol>
                </nav>
            </span>
            <div class="maoscroll" style="height:90vh;">
                <div class="col-lg-12 col-12">
                    <div class="row">
                        <?php
                        require "connection.php";
                        $d = new DateTime();
                        $tz = new DateTimeZone("Asia/Colombo");
                        $d->setTimezone($tz);
                        $dateNew = $d->format("Y-m-d H:i:s");


                        $bhm_rs = Database::search("SELECT * FROM `user` WHERE `user_type_id`='2'");
                        $bhm_num = $bhm_rs->num_rows;

                        for ($x = 0; $x < $bhm_num; $x++) {
                            $bhm_data = $bhm_rs->fetch_assoc();
                        ?>
                            <div class="col-lg-3 col-12 mt-2">
                                <div class="card" style="width: 100%;">
                                    <div class="card-body">
                                        <h5 class="card-title fw-bold text-uppercase">Student</h5>
                                        <h6 class="card-subtitle mb-2 text-muted text-uppercase"><?php echo $bhm_data["fname"]; ?> <?php echo $bhm_data["lname"]; ?></h6>
                                        <hr/>
                                        <h6 class="card-subtitle mb-2 text-muted text-uppercase opacity-75 text-danger"><span class="small">Mobile : <input value="<?php echo $bhm_data["mobile"]; ?>" disabled class="border border-0" /></span></h6>
                                        <h6 class="card-subtitle mb-2 text-muted text-uppercase opacity-75 text-danger"><span class="small">Email : <input value="<?php echo $bhm_data["email"]; ?>" disabled class="border border-0" /></span></h6>
                                        <hr class="border border-3 border-dark" />
                                        </p>
                                        <div class="col-lg-12 col-12 ">
                                            <div class="row">
                                                <div class="btn-group btn-group-sm" role="group" aria-label="Small button group">
                                                    <?php

                                                    if ($bhm_data["status"] == 1) {
                                                    ?>
                                                        <button class="btn btn-danger" id="ub<?php echo $bhm_data['email']; ?>" onclick="blockUser('<?php echo $bhm_data['email']; ?>');">Block</button>
                                                    <?php

                                                    } else {
                                                    ?>
                                                        <button class="btn btn-success" id="ub<?php echo $bhm_data['email']; ?>" onclick="blockUser('<?php echo $bhm_data['email']; ?>');">Unblock</button>
                                                    <?php

                                                    }

                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php

                        }

                        ?>



                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>