<?php

session_start();


if (isset($_SESSION["u"])) {

    $fname = $_POST["fn"];
    $lname = $_POST["ln"];

    if (empty($fname)) {
        echo ("Entering your first name is mandatory.");
    } else if (empty($lname)) {
        echo ("Entering your last name is mandatory.");
    } else {
        include "connection.php";
        Database::iud("UPDATE `user` SET `fname`='" . $fname . "',`lname` = '" . $lname . "' WHERE `email`='" . $_SESSION["u"]["email"] . "'");

        echo ("success");
    }
} else {
    echo ("Please Login First");
}

?>