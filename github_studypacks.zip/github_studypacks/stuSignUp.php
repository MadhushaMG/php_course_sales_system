<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp | STUDY-PACKS</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
    <link rel="shortcut icon" href="./resources/systemImages/mortarboard.png" type="image/png">
</head>

<body class="bgn">
    <div class="container-fluid ">
        <div class="col-lg-12 col-12 ">
            <div class="row ">
                <div class="col-lg-12 col-12">
                    <div class="row">
                        <div class="col-lg-6 col-6 text-start">
                            <h4 class="text-info fw-bold mt-2">STUDY-PACKS</h4>
                        </div>
                        <div class="col-lg-6 col-6 text-end mt-2">
                            <a href="index.php"><button type="button" class="btn btn-danger btn-sm fw-bold">Sign In</button></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 "></div>
                <div class="col-lg-8 col-12" style="margin-top:10%;">
                    <div>
                        <span class="fs-4 text-white fw-bold">Joining STUDY-PACKS is easy.</span><br />
                        <span class="fs-6 text-white ">Education is a process of gathering knowledge.

                            Socrates said that the highest thing is knowledge. Knowledge is the highest person. It comes from education.</span><br />

                        <div id="step1" class="d-block">
                            <div class="progress mt-2">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-label="Animated striped example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 25%"></div>
                            </div>
                            <br />
                            <div class="col-lg-12 col-12">
                                <div class="row">
                                    <div class="col-lg-6 col-12 mt-2">
                                        <span class="text-white fs-6">First name</span>
                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signupfname" placeholder="Chals">
                                    </div>
                                    <div class="col-lg-6 col-12 mt-2">
                                        <span class="text-white fs-6">Last name</span>
                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signuplname" placeholder="Babege">
                                    </div>
                                    <div class="col-lg-12 col-12 mt-2">
                                        <span class="text-white fs-6">Email</span>
                                        <input type="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signupemail" placeholder="chals@codplus.com">
                                        <div class="text-end text-uppercase"><span id="signUpmsg1" class="text-info fs-6"></span></div>
                                    </div>
                                    <div class="col-lg-12 col-12 mb-5">
                                        <button class="btn btn-danger mt-2 mt-2 mb-5 w-100" type="button" onclick="step1btn();">Next</button>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div id="step2" class="d-none">
                            <div class="progress mt-2">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-label="Animated striped example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 50%"></div>
                            </div>
                            <br />
                            <div class="col-lg-12 col-12">
                                <div class="row">
                                    <div class="col-lg-12 col-12 mt-2">
                                        <span class="text-white fs-6">Phone number</span>
                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signupnumber" placeholder="+94702387985">
                                    </div>
                                    <div class="col-lg-12 col-12 mt-2">
                                        <span class="text-white fs-6">Password</span>
                                        <input type="password" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signuppw" placeholder="Chals@2022">
                                    </div>
                                    <div class="col-lg-12 col-12 mt-2">
                                        <span class="text-white fs-6">Re-Password</span>
                                        <input type="password" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signuprpw" placeholder="Chals@2022">
                                        <div class="text-end text-uppercase"><span id="signUpmsg2" class="text-info fs-6"></span></div>
                                    </div>
                                    <div class="col-lg-6 col-12">
                                        <button class="btn btn-danger mt-2 mt-2 mb-2 w-100" type="button" onclick="step2bbtn();">Back</button>
                                    </div>
                                    <div class="col-lg-6 col-12">
                                        <button class="btn btn-danger mt-2 mt-2 mb-2 w-100" type="button" onclick="step2btn();">Next</button>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div id="step3" class="d-none">
                            <div class="progress mt-2">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-label="Animated striped example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 75%"></div>
                            </div>
                            <br />
                            <div class="col-lg-12 col-12">
                                <div class="row">
                                    <div class="col-lg-12 col-12 mt-2">
                                        <span class="text-white fs-6 ">User name</span>
                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signUpUsername" readonly>
                                        <div class="text-end text-uppercase"><span id="signUpmsg2" class="text-info fs-6"></span></div>
                                    </div>
                                    <div class="col-lg-6 col-12">
                                        <button class="btn btn-danger mt-2 mt-2 mb-2 w-100" type="button" onclick="step3bbtn();">Back</button>
                                    </div>
                                    <div class="col-lg-6 col-12">
                                        <button class="btn btn-danger mt-2 mt-2 mb-2 w-100 d-block" type="button" onclick="step3btn();" id="sentButton">Next</button>
                                        <button class="btn btn-danger mt-2 mt-2 mb-2 w-100 d-none" type="button" id="sentPendingButton" disabled>
                                            <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
                                            Sending Verification Code...
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="step4" class="d-none">
                            <div class="progress mt-2">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-label="Animated striped example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
                            </div>
                            <br />
                            <div class="col-lg-12 col-12">
                                <div class="row">
                                    <div class="col-lg-6 col-12 mt-2">
                                        <span class="text-white fs-6">Email</span>
                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signupEmailView" readonly />
                                    </div>
                                    <div class="col-lg-6 col-12 mt-2">
                                        <span class="text-white fs-6">Verification Code</span>
                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" id="signupverification" placeholder="20003593">
                                    </div>
                                    <div class="col-lg-12 col-12 mt-2">
                                        <span class="text-info fs-6">Your email has received the verification code. Please enter your verification code and verify your email address for your account success.</span>
                                    </div>
                                    <span class="text-white" id="signUpmsg4"></span>
                                    <div class="col-lg-6 col-12">
                                        <button class="btn btn-danger mt-2 mt-2 mb-2 w-100" type="button" onclick="step4bbtn();">Back</button>
                                    </div>
                                    <div class="col-lg-6 col-12">
                                        <button class="btn btn-danger mt-2 mt-2 mb-2 w-100" type="button" onclick="step4btn();">Next</button>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="col-lg-2 "></div>
            </div>
        </div>
    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>