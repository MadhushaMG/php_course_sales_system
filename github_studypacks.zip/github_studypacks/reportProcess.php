<?php

require "connection.php";
session_start();

$report = $_POST["r"];

$d = new DateTime();
$tz = new DateTimeZone("Asia/Colombo");
$d->setTimezone($tz);
$date = $d->format("Y-m-d H:i:s");

if(empty($report)){
    echo ("Enter your report");
}else{
   
    Database::iud("INSERT INTO `report` (`user_id`,`content`,`date`) VALUES ('".$_SESSION['u']["id"]."','".$report."','".$date ."')");
        echo ("success");


}
