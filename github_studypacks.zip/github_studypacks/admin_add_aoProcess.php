<?php

session_start();
require "connection.php";
require "SMTP.php";
require "PHPMailer.php";
require "Exception.php";

use PHPMailer\PHPMailer\PHPMailer;

$fname = $_POST["f"];
$lname = $_POST["l"];
$email = $_POST["e"];
$num = $_POST["n"];
$cn = $_POST['ca'];
$st = Database::search("SELECT * FROM `user` WHERE `email` = '".$email."'");
$stnum = $st->num_rows;

if (empty($fname)) {
    echo ("Please enter First Name !!!");
} else if (strlen($fname) > 50) {
    echo ("First Name must have less than 50 characters");
} else if (empty($lname)) {
    echo ("Please enter  Last Name !!!");
} else if (strlen($lname) > 50) {
    echo ("Last Name must have less than 50 characters");
} else if (empty($email)) {
    echo ("Please enter  Email !!!");
} else if (strlen($email) >= 100) {
    echo ("Email must have less than 100 characters");
} else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo ("Invalid Email !!!");
} else if($num == 1){
    echo ("Phone number is already exit.");
} else if($stnum ==  1){
    echo ("Registered user!");
}else {

    $d = new DateTime();
    $tz = new DateTimeZone("Asia/Colombo");
    $d->setTimezone($tz);
    $date = $d->format("Y-m-d H:i:s");

    //Create a user name
    $un = $fname.'@'.$num;

    //Create a password
    $code = uniqid();

    $dbn = Database::iud("INSERT INTO `user` (`user_type_id`, `fname`, `lname`, `address`, `mobile`, `email`, `password`, `status`, `profile_img`,`otp`) VALUES ('2', '".$fname."', '".$lname."', 'city', '".$num."', '".$email."', '".$code."', '1', '','123')");
    $nud = Database::search("SELECT * FROM `user` WHERE `email` = '".$email."'");
    $nudata = $nud->fetch_assoc();
    if (isset($cn)) {
        // Convert the comma-separated string into an array
        $caArray = explode(',', $cn);
    
        // Count the number of elements in the array
        $count = count($caArray);
    
        // Output all values in the array
        for ($x = 0; $x < $count; $x++) {
            // Sanitize and validate $caArray[$x] before using it in the query
            $courseId = $caArray[$x];
    
            // Check if the user already has the course
            $checkQuery = "SELECT * FROM `user_has_course` WHERE `user_id` = '".$nudata['id']."' AND `course_id` = '".$courseId."'";
            $checkResult = Database::search($checkQuery);
    
            if ($checkResult->num_rows == 0) {
                // If the user doesn't have the course, insert the record
                Database::iud("INSERT INTO `user_has_course` (`user_id`, `course_id`) VALUES ('".$nudata['id']."', '".$courseId."') ");
            } else {
                echo("User already has the course with ID: ".$courseId);
            }
        }
    } else {
        echo "Error: 'cn' is not set.";
    }
    

    //Sent email to AO 

    $mail = new PHPMailer;
    $mail->IsSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'test.application200@gmail.com';
    $mail->Password = 'rxelvllqxudovixm';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom('test.application200@gmail.com', 'Student Invition');
    $mail->addReplyTo('test.application200@gmail.com', 'Student Invition');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'test.application200@gmail.com';
    $bodyContent = '
    <!DOCTYPE html>
<html lang="en">

<head>
<title>Email verify</title>

<link rel="stylesheet" href="bootstrap.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
<link rel="stylesheet" href="style.css" />
</head>

<body>
<div class="col-lg-12 col-12 container-fluid">
    <div class="row">
        <div class=" col-lg-10 offset-1 col-12 emb ">
            <h1 class=" fw-bold  ">Study-Pack</h1><br />
            <h2 class=" fw-bold  ">SYSTEM INVITATION</h2>
            <br />
            <hr />
            <h5>
            Study-Pack is a robust and user-friendly IT system designed to streamline and enhance the educational experience. Tailored for modern learning environments, Study-Pack empowers educators, students, and administrators with a comprehensive suite of tools and features. 
            From intuitive course management and interactive content delivery to seamless communication channels, Study-Pack is a dynamic platform that fosters collaboration and engagement.
            </h5>

            <h3>Good day, ' . $fname . '. Welcome to the CODPLUS LMS system. You have been selected as a teacher for this system. You can enter the username and password received here into 
                the system and then enter the verification code sent to your email address to enter the system.<br/>
                <span class="fw-bold">System Access:</span><br/><br/>
                Username - ' . $email . '<br/>
                password - ' . $code . '<br/>


            </h3>
                <br/><br/><br/>
                <br/><br/><br/>
                <br/><br/><br/>
                <h6 class=" text-uppercase fw-bold">Please note that this is a system-generated email. <br/><small class=" text-uppercase">Copyright © 2022 CODARA All Rights Reserved</small></h6>
        </div>
    </div>
</div>
</body>

</html>';

    $mail->Body    = $bodyContent;
    if (!$mail->send()) {
        echo 'Email sending failed';
    } else {
        echo 'success';
    }
}

?>
