<?php
require("connection.php");

$courseName = $_POST["cname"];
$cdes = $_POST["cdes"];
$cln = $_POST["cln"];

if (empty($courseName)) {
    echo ("Select course name");
} else if (empty($cdes)) {
    echo ("Warning! Please enter the date.");
} else if (empty($cln)) {
    echo ("Warning! Please enter the time.");
} else {
    Database::iud("INSERT INTO `course` (`name`,`description`,`lecturer_name`,`status`) VALUES ('" . $courseName . "','" . $cdes . "','" . $cln . "','1')");
    echo("done");
}
