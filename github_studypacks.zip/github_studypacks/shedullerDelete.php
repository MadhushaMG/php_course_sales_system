<?php
require("connection.php");

$sheudllerID = $_POST["id"];

Database::iud("DELETE FROM `shedule` WHERE `id` = '" . $sheudllerID . "'");
echo("done");
?>
