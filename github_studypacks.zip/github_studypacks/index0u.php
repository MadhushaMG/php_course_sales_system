<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>studypacks</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body class="bg">
    <div class="container-fluid">
        <div class="col-lg-12 col-12">
            <div class="row">
                <div class="col-lg-12 col-12">
                    <div class="row">
                        <div class="col-lg-6 col-6 text-start">
                            <h4 class="text-info fw-bold mt-2">studypacks</h4>
                        </div>
                        <div class="col-lg-6 col-6 text-end mt-2">
                            <a href="stuSignUp.php"><button type="button" class="btn btn-danger btn-sm fw-bold">Sign Up</button></a>
                        </div>
                        <div class="mt-5 text-center text-white topicspace">
                            <h2 class="fw-bold  text-uppercase "><span class="htcani1">Knowledge is</span><span class="htcani2"> your power</span></h2>
                            <h4 class="fs-5 text-uppercase">www.studypacks.lk</h4>
                        </div>
                        <div class="mt-4 text-center text-info ">
                            <h5 class="fs-6">Ready to studey? Enter your email to create or restart your membership.</h5>
                        </div>
                        <div class="col-lg-12 col-12 mb-5">
                            <div class="row">
                                <div class="col-lg-3"></div>
                                <div class="col-lg-6 col-12 mb-5">
                                    <div class="input-group mb-3 input-group-lg">
                                        <input type="text" class="form-control" placeholder="ex: username@company.com" aria-describedby="button-addon2" id="email">
                                        <button class="btn btn-danger text-uppercase" type="button" onclick="umailcheck();" id="emailbtn">Get Start <i class="bi bi-arrow-right"></i></button>
                                    </div>
                                    <div class="d-none" id="uemailerror">
                                        <div class="card card-body text-white fw-bold fs-6 bgwarningimg text-uppercase " id="msg1"></div>
                                    </div>
                                </div>
                                <div class="col-lg-3"></div>
                            </div>
                        </div>
                        <div class="row g-0 position-relative bgimg">
                            <div class="col-md-3 mb-md-0 p-md-4 d-lg-block d-none">
                                <img src="resources/systemImages/teacher.png" class="teacherimg" alt="...">
                            </div>
                            <div class="col-md-9 p-4 ps-md-0 text-white">
                                <h4 class="mt-0 fs-4 fw-bold htopic">Hello teachers !!!</h4>
                                <p class="htopic">Here is a great opportunity for you, would you like to impart knowledge to an unlimited number of students with your teaching ability?
                                    Then this opportunity is for you. Here you can start a new course and sell it yourself. The new global school that suits you!</p>

                                <a href="teachersLogin.php"><button type="button" class="btn btn-outline-danger ">Apply here</button></a>
                            </div>
                        </div>

                        <div class="row g-0 position-relative bgimg ">
                            <div class="col-md-12 p-4  text-white htopic">
                                <hr class="border border-danger border-4 opacity-50">
                                <h4 class="mt-0 fs-4 fw-bold"><i class="bi bi-patch-question"></i> About Courses</h4>
                                <div class="col-lg-12 col-12">
                                    <div class="row maoscroll" style="height:90vh; font-family: 'Courier New', Courier, monospace;">
                                        <div class="col-lg-12 col-12">
                                            <div class="row">
                                                <?php
                                                require "connection.php";
                                                $course = Database::search("SELECT * FROM `course`");
                                              
                                                for ($y = 0; $y < 4; $y++) {
                                                    $cData = $course->fetch_assoc();
                                                ?>
                                                    <div class="col-lg-3 col-12 mt-2">
                                                        <div class="card" style="width: 100%;">
                                                            <div class="card-header">
                                                                <span class="badge text-bg-primary">Date: <?php echo  $cData['name']; ?></span>
                                                            </div>
                                                            <div class="card-body">
                                                                <h5 class="card-title fw-bold text-uppercase"><?php echo $cData['name']; ?></h5>
                                                                <h6 class="card-subtitle mb-2 text-muted text-uppercase">Lecturer: <?php echo $cData["lecturer_name"]; ?></h6>
                                                                <h6 class="card-subtitle mb-2 text-muted text-uppercase">Time: </h6>
                                                                <hr class="border border-3 border-dark" />
                                                                <div class="col-lg-12 col-12">
                                                                    <div class="row">
                                                                        <button class="btn btn-danger">Add</button>
                                                                    </div>
                                                                </div>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php
                                                }

                                                ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row g-0 position-relative bgimg">
                            <div class="col-md-12 p-4  text-white">
                                <hr class="border border-danger border-4 opacity-50">
                                <h4 class="mt-0 fs-4 fw-bold htopic"><i class="bi bi-patch-question"></i> Frequently Asked Questions</h4>
                                <div class="col-lg-12 col-12 container-fluid">
                                    <div class="row">
                                        <div class="col-lg-10 col-12 offset-lg-1">
                                            <button type="button" class="btn btn-dark w-100 text-start"><span class="fs-4 position-absolute">What is codplus?</span>
                                                <div class="text-end"><i class="bi bi-plus-lg fs-2" data-bs-toggle="collapse" data-bs-target="#q1" aria-expanded="false" aria-controls="q1"></i></div>
                                            </button>
                                            <div class="collapse mt-1" id="q1">
                                                <div class="card card-body bg-dark">
                                                    This is a course selling and buying system. If you are a teacher you can upload courses and earn money. If you are a student you can buy and learn courses.
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-dark w-100 text-start mt-2"><span class="fs-4 position-absolute">How much does the course cost?</span>
                                                <div class="text-end"><i class="bi bi-plus-lg fs-2" data-bs-toggle="collapse" data-bs-target="#q2" aria-expanded="false" aria-controls="q2"></i></div>
                                            </button>
                                            <div class="collapse mt-1" id="q2">
                                                <div class="card card-body bg-dark">
                                                    The cost of the course depends on the specific course you are interested in. Each course has its own price, which is determined by a number of factors, such as the length of the course, the level of expertise of the instructor, and the amount of resources included in the course. To view the price of a specific course, simply navigate to the course page on our website and the price will be displayed.
                                                    We also occasionally offer discounts and promotions on our courses, so be sure to keep an eye out for any special deals.
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-dark w-100 text-start mt-2"><span class="fs-4 position-absolute">What are the other services?</span>
                                                <div class="text-end"><i class="bi bi-plus-lg fs-2" data-bs-toggle="collapse" data-bs-target="#q3" aria-expanded="false" aria-controls="q3"></i></div>
                                            </button>
                                            <div class="collapse mt-1" id="q3">
                                                <div class="card card-body bg-dark">
                                                    In addition to social education networking, chat, and quick payment, there are a variety of other services that may be available on your platform. Some common additional services include personalized learning plans, course recommendations based on user interests, progress tracking, certificate and badge issuance upon completion of a course, and access to a community forum where users can connect with each other and share knowledge. Other potential services could include live online events such as webinars or Q&A sessions with industry experts, access to additional learning resources such as eBooks or online courses, and career services such as job search assistance or resume review. The specific services offered on your platform will depend on the goals and vision of your business,
                                                    as well as the needs and preferences of your target audience.
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-dark w-100 text-start mt-2"><span class="fs-4 position-absolute">What is edu-social network?</span>
                                                <div class="text-end"><i class="bi bi-plus-lg fs-2" data-bs-toggle="collapse" data-bs-target="#q4" aria-expanded="false" aria-controls="q4"></i></div>
                                            </button>
                                            <div class="collapse mt-1" id="q4">
                                                <div class="card card-body bg-dark">
                                                    An edu-social network is a platform that combines the social features of a social network with the educational components of an online learning platform. This type of network is designed to facilitate communication and collaboration among students, teachers, and other members of the education community. Like Facebook, an edu-social network allows users to create profiles, connect with friends, share information and updates, and participate in discussions. However, unlike Facebook, the focus of an edu-social network is on learning and education, rather than socializing and entertainment. Users can join groups based on their interests or academic subjects, participate in forums and chat rooms, and even attend virtual classes and lectures. The goal of an edu-social network is to create a community of learners who can support and learn from each other, regardless of their physical location or time zone. By leveraging the power of social networking and online learning,
                                                    edu-social networks have the potential to transform the way we learn and share knowledge.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php include "footer.php" ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>