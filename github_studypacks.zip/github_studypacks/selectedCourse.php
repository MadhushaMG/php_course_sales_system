<?php

session_start();

require "connection.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sheduller</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <div class="col-lg-12 col-12 container-fluid">
        <div class="row">
            <span class="text-start">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">My courses</li>
                    </ol>
                </nav>
            </span>
            <div class="col-lg-12 col-12">
                <div class="row maoscroll" style="height:90vh;">
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <?php
                            $st_rs = Database::search("SELECT * FROM `user_has_course` WHERE `user_id` = '" . $_SESSION['u']["id"] . "'");
                            $strows = $st_rs->num_rows;
                            if ($strows == 0) { ?>
                                <div class="col-lg-12 col-12 container-fluid">
                                    <div class="row">
                                        <div class="card border border-0 text-center" style="margin-top: 40vh;">
                                            <span>Not registered for courses.<img src="resources/systemImages/Magnify-1.8s-200px.svg" style="width: 40px;" /></span>
                                        </div>
                                    </div>

                                </div>
                                <?php } else {
                                for ($x = 0; $x < $strows; $x++) {
                                    $stData = $st_rs->fetch_assoc();
                                    $course = Database::search("SELECT * FROM `course` WHERE `id` = '" . $stData['course_id'] . "'");
                                    $crsrw = $course->num_rows;
                                   
                                    for ($y = 0; $y < $crsrw; $y++) {
                                        $cData = $course->fetch_assoc();
                                        $view_Course = 20;
                                        
                                ?>
                                        <div class="col-lg-3 col-12 mt-2">
                                            <div class="card ccrd" style="width: 100%;">
                                                <div class="card-header text-center" style="background-image: url('./resources/systemImages/ColoredShapes.svg'); height: 60px; background-size: cover;">
                                                    <h6 class="card-title text-uppercase text-light fw-bold  mb-0 opacity-75">STUDY-PACKS</h6>
                                                    <small class="text-light mt-0 opacity-75">Start the learning process again</small>
                                                </div>
                                                <div class="card-body">
                                                    <div class="fs-5 text-center fw-bold text-uppercase">
                                                        <?php echo $cData["name"]; ?>
                                                    </div>

                                                    <div class="progress mt-2" role="progressbar" aria-label="Example 1px high" aria-valuenow="<?php echo ($view_Course); ?>" aria-valuemin="0" aria-valuemax="100" style="height: 10px">
                                                        <div class="progress-bar" style="width: 25%"></div>
                                                    </div>
                                                    <small class="text-uppercase">You have completed about <?php echo ($view_Course); ?>% of this course. This is led by <?php
                                                                                                                                                                        $substring = substr($cData["lecturer_name"], 0, 6);

                                                                                                                                                                        echo ($substring);

                                                                                                                                                                        ?>.</small>
                                                    <hr />
                                                    <div class="col-lg-12 col-12 mt-1">
                                                        <div class="row">
                                                            <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                                                <button type="button" class="btn btn-light border border-1"><i class="bi bi-view-list"></i> Overview</button>
                                                                <button type="button" class="btn btn-light border border-1" onclick="selectedCourse(id='<?php echo $cData['id']; ?>');"><i class="bi bi-play-circle-fill"></i> Goto</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                            <?php
                                    }
                                }
                            }
                            ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>

</html>