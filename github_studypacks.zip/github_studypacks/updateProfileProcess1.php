<?php

session_start();

include "connection.php";

if (isset($_SESSION["u"])) {

    $oldpw = $_POST["opw"];
    $newpw1 = $_POST["n1pw"];
    $newpw2 = $_POST["n2pw"];

    $user_rs = Database::search("SELECT * FROM `user` WHERE `id`='" . $_SESSION['u']["id"] . "'");

    $user_data = $user_rs->fetch_assoc();

    if (empty($oldpw)) {
        echo ("Entering your old password is mandatory.");
    } else if ($user_data["password"] !== $oldpw ) {
        echo ("Invalid password! Enter your valid password.");
    }else if (empty($newpw1)) {
        echo ("Enter your new password.");
    } else {
        Database::iud("UPDATE `user` SET `password`='" . $newpw2 . "' WHERE `email`='" . $_SESSION["u"]["email"] . "'");

        echo ("success");
    }
} else {
    echo ("Please Login First");
}
?>