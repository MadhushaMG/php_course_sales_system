<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>footer | studypacks</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>

    <footer class="pb-5 pt-4 mt-5 fbg container-fluid">

        <div class="col-lg-12 col-12">
            <div class="row">
                <div class="col-lg-3 col-2">
                    <div class="list">
                        <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
                            Help
                        </a>
                        <a href="#" class="list-group-item list-group-item-action">Privacy</a>
                        <a href="#" class="list-group-item list-group-item-action">Help Center</a>
                        <a href="#" class="list-group-item list-group-item-action">FAQ</a>

                    </div>
                </div>
                <div class="col-lg-3 col-5 ">
                    <div class="list">
                        <a href="#" class="list-group-item list-group-item-action">About</a>
                        <a href="#" class="list-group-item list-group-item-action">Package Details</a>

                    </div>
                </div>
                <div class="col-lg-3 col-4 d-lg-block  d-none text-infotext-end">
                    <p>Here we at studypacks.lk™ have included advanced subject areas to enhance your knowledge level.</p>
                </div>
                <div class="col-lg-3 col-5 text-end">
                    <p>studypacks.lk <i class="bi bi-globe"></i> </p>
                    <p> info@studypacks.lk <i class="bi bi-at"></i></p>
                    <p> num <i class="bi bi-telephone-fill"></i></p>

                </div>
                <div class="col-lg-3 d-lg-none d-sm-block col-12 text-center mt-2">
                    <p>Here we at studypacks.lk™ have included advanced subject areas to enhance your knowledge level.</p>
                </div>
                <hr />
                <div class="col-lg-12 col-12 text-center">
                    <ul class="list-unstyled list-inline">

                        <li class="list-inline-item">
                            <a href="#" class="form-floating text-white">
                                <i class="bi bi-facebook" style="font-size: 22px;"></i>
                            </a>
                        </li>

                        <li class="list-inline-item">
                            <a href="#" class="form-floating text-white">
                                <i class="bi bi-twitter" style="font-size: 22px;"></i>
                            </a>
                        </li>

                        <li class="list-inline-item">
                            <a href="#" class="form-floating text-white">
                                <i class="bi bi-linkedin" style="font-size: 22px;"></i>
                            </a>
                        </li>

                        <li class="list-inline-item">
                            <a href="#" class="form-floating text-white">
                                <i class="bi bi-youtube" style="font-size: 22px;"></i>
                            </a>
                        </li>

                    </ul>

                </div>
                <div class="col-lg-12 col-12 text-center">
                    <dic class="row">

                        <p>Copyright &copy; 2023 Trimana business solutions All Rights Reserved</p>
 
                    </dic>
                </div>
            </div>
        </div>

    </footer>
</body>



<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>

</html>