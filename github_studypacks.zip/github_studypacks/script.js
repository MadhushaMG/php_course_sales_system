// scrol toTop button

const toTop = document.querySelector(".to-top");

window.addEventListener("scroll", () => {
  if (window.pageYOffset > 10) {
    toTop.classList.add("active");
  } else {
    toTop.classList.remove("active");
  }
})


//signUp Page

//step var
var step1 = document.getElementById("step1");
var step2 = document.getElementById("step2");
var step3 = document.getElementById("step3");
var step4 = document.getElementById("step4");

//input var 
var signUpfname = document.getElementById("signupfname");
var signUplname = document.getElementById("signuplname");
var signUpemail = document.getElementById("signupemail");
var signUpcountry = document.getElementById("signupcountry");
var signUpnumber = document.getElementById("signupnumber");
var signUppw = document.getElementById("signuppw");
var signUprpw = document.getElementById("signuprpw");
var signUpOTP = document.getElementById("signupverification"); //verification code


//Next 


//StepProcess-01
function step1btn() {

  var form = new FormData;
  form.append("f", signUpfname.value);
  form.append("l", signUplname.value);
  form.append("e", signUpemail.value);

  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4) {
      var text = request.responseText;
      if (text == "success") {
        step1.classList.remove("d-block");
        step1.classList.add("d-none");
        step2.classList.remove("d-none");
        step2.classList.add("d-block");

      } else {
        document.getElementById("signUpmsg1").innerHTML = text;
      }
    }
  }

  request.open("POST", "stepProcess1.php", true);
  request.send(form);


}

//StepProcess-02
function step2btn() {
  var form = new FormData;
  form.append("n", signUpnumber.value);
  form.append("pw", signUppw.value);
  form.append("prw",signUprpw.value);

  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4) {
      var text = request.responseText;
      if (text == "success") {
        step1.classList.remove("d-block");
        step1.classList.add("d-none");
        step2.classList.remove("d-block");
        step2.classList.add("d-none");
        step3.classList.remove("d-none");
        step3.classList.add("d-block");
        
        uname = signUpfname.value +"@" +signUpnumber.value;
        username.value = uname;

      } else {
        document.getElementById("signUpmsg2").innerHTML = text;
      }
    }
  }

  request.open("POST", "stepProcess2.php", true);
  request.send(form);
}



//StepProcess-03
function step3btn() {
  
  var sentButton = document.getElementById("sentButton");
  var sentPendingButton = document.getElementById("sentPendingButton");
  
  sentButton.classList.remove("d-block");
  sentButton.classList.add("d-none");
  sentPendingButton.classList.remove("d-none");
  sentPendingButton.classList.add("d-block");

  var form = new FormData;
    form.append("f", signUpfname.value);
    form.append("l", signUplname.value);
    form.append("e", signUpemail.value);
    form.append("c", signUpcountry.value);
    form.append("n", signUpnumber.value);
    form.append("pw", signUppw.value);
    form.append("otp",signUpOTP.value);

  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4) {
      var text = request.responseText;
      if (text == "success") {
        step1.classList.remove("d-block");
        step1.classList.add("d-none");
        step2.classList.remove("d-block");
        step2.classList.add("d-none");
        step3.classList.remove("d-block");
        step3.classList.add("d-none");
        step4.classList.remove("d-none");
        step4.classList.add("d-block");
        
        var signupEmailView = document.getElementById("signupEmailView");
        signupEmailView.value = signUpemail.value;
        
      } else {
        document.getElementById("signUpmsg3").innerHTML = text;
      }
    }
  }

  request.open("POST", "stepProcess3.php", true);
  request.send(form);
}



//StepProcess-04
function step4btn(){
    var form = new FormData;

    form.append("otp",signUpOTP.value);
    
    var request = new XMLHttpRequest();
  
    request.onreadystatechange = function () {
      if (request.readyState == 4) {
        var text = request.responseText;
        if (text == "success") {
          window.location = "index.php";
        } else {
          document.getElementById("signUpmsg4").innerHTML = text;
        }
      }
    }
  
    request.open("POST", "signupProcess.php", true);
    request.send(form);
  }


//Back

function step4bbtn(){
    step3.classList.remove("d-none");
    step3.classList.add("d-block");
    step4.classList.remove("d-block");
    step4.classList.add("d-none");

     
    sentButton.classList.remove("d-none");
    sentButton.classList.add("d-block");
    sentPendingButton.classList.remove("d-block");
    sentPendingButton.classList.add("d-none");
}

function step3bbtn(){
    step2.classList.remove("d-none");
    step2.classList.add("d-block");
    step3.classList.remove("d-block");
    step3.classList.add("d-none");
}

function step2bbtn(){
    step1.classList.remove("d-none");
    step1.classList.add("d-block");
    step2.classList.remove("d-block");
    step2.classList.add("d-none");
}

//signIn mail check process

function umailcheck() {

  var email = document.getElementById("email");

  var f = new FormData();
  f.append("e", email.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "success") {
        window.location = "signin.php";
      }
      else {
        document.getElementById("uemailerror").classList = "d-block";
        document.getElementById("msg1").innerHTML = t;
      }

    }
  };

  r.open("POST", "signin.php", true);
  r.open("POST", "signinProcess.php", true);
  r.send(f);

}

//Login Process
function signIn() {
    var email = document.getElementById("emailset");
    var password = document.getElementById("signInpid");
    var rememberme = document.getElementById("rememberme");
  
    var f = new FormData();
    f.append("e", email.value);
    f.append("p", password.value);
    f.append("r", rememberme.checked);
  
    var r = new XMLHttpRequest();
  
    r.onreadystatechange = function () {
      if (r.readyState == 4) {
        var t = r.responseText;
        if (t == "success") {       
          window.location = "dashboard.php";
        }else if(t == "sameuser"){
          alert("Warning! You are trying to log into the system with another person's account. Please login to your account.");
        }else {
          document.getElementById("msg3").innerHTML = t;
        }
        
      }
    };
  
    r.open("POST", "loginProcess.php", true);
    r.send(f);
  }
//show & hide password

function showPassword1() {
  var i = document.getElementById("signInpid");
  var eye = document.getElementById("e1");

  if (i.type == "password") {
    i.type = "text";
    eye.className = "bi bi-eye-fill";
  } else {
    i.type = "password";
    eye.className = "bi bi-eye-slash-fill";
  }

}
function showPassword2() {

  var i = document.getElementById("npi");
  var eye = document.getElementById("e2");

  if (i.type == "password") {
    i.type = "text";
    eye.className = "bi bi-eye-fill";
  } else {
    i.type = "password";
    eye.className = "bi bi-eye-slash-fill";
  }

}
function showPassword4() {

  var i = document.getElementById("vc");
  var eye = document.getElementById("e4");

  if (i.type == "password") {
    i.type = "text";
    eye.className = "bi bi-eye-fill";
  } else {
    i.type = "password";
    eye.className = "bi bi-eye-slash-fill";
  }

}


function showPassword3() {

  var i = document.getElementById("rnp");
  var eye = document.getElementById("e3");

  if (i.type == "password") {
    i.type = "text";
    eye.className = "bi bi-eye-fill";
  } else {
    i.type = "password";
    eye.className = "bi bi-eye-slash-fill";
  }

}


//forgotPassword

function forgotPassword() {
  var email = document.getElementById("emailset");
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "Success") {
        alert("Verification code has sent to your email. Please check your inbox");
        var m = document.getElementById("forgotPasswordModal");
        window.location = "resetPasswordPage.php";
      } else {
        alert(t);
      }

    }
  }

  r.open("GET", "forgotPasswordProcess.php?e=" + email.value, true);
  r.send();

}

//resetPassword

function resetpw() {

  var email = document.getElementById("emailset");
  var np = document.getElementById("npi");
  var rnp = document.getElementById("rnp");
  var vcode = document.getElementById("vc");

  var f = new FormData();
  f.append("e", email.value);
  f.append("n", np.value);
  f.append("r", rnp.value);
  f.append("v", vcode.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "success") {
        alert("Password reset success");
        window.location = "index.php";
      } else {
        alert(t);
      }

    }
  };

  r.open("POST", "resetPassword.php", true);
  r.send(f);

}

  //Change window

function loadContent(url) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("content").innerHTML = this.responseText;
      }
    };
    xhttp.open("GET", url, true);
    xhttp.send();
  }
  
  //Sheduller

  function sheduller() {
    var courseName = document.getElementById("selectCourse");
    var sheduleDate = document.getElementById("sheduleDate");
    var sheduleTime = document.getElementById("sheduleTime");
    var zoomLink = document.getElementById("zoomLink");
    var sheduleStatus = document.getElementById("connectionType");
 
    var f = new FormData();
    f.append("cn", courseName.value);
    f.append("sd", sheduleDate.value);
    f.append("st", sheduleTime.value);
    f.append("zl", zoomLink.value);
    f.append("ctype", sheduleStatus.value);

    var r = new XMLHttpRequest();
  
    r.onreadystatechange = function () {
      if (r.readyState == 4) {
        var t = r.responseText;
        if (t == "done") {
          alert("Schedule saved.");     
          loadContent('sheduller.php');
        }else {
          document.getElementById("msgshedule").innerHTML = t;
        }
        
      }
    };
  
    r.open("POST", "shedullerProcess.php", true);
    r.send(f);
  }

  //update shedule
  var sheudllerID = 0; 
  function updateShedule(id) {
    sheudllerID = id; 
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Define the callback function to handle the response
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Parse the JSON response
            var data = JSON.parse(xhr.responseText);

            // Populate input fields
            var selectElement = document.getElementById("selectCourse");
            selectElement.value = data.course_id;
            document.getElementById("sheduleDate").value = data.date;
            document.getElementById("sheduleTime").value = data.time;
            document.getElementById("zoomLink").value = data.link;

            document.getElementById("ssb").classList = "d-none" ; 
            document.getElementById("sab").classList = "btn-group d-block" ; 
        }
    };

    // Open a GET request to your server with the ID as a parameter
    xhr.open("GET", "shedullerUpdate.php?id=" + id, true);
    // Send the request
    xhr.send();
}
function updatesheduleData(){
  var courseName = document.getElementById("selectCourse");
    var sheduleDate = document.getElementById("sheduleDate");
    var sheduleTime = document.getElementById("sheduleTime");
    var zoomLink = document.getElementById("zoomLink");
    var sheduleStatus = document.getElementById("connectionType");
 
    var f = new FormData();
    f.append("cn", courseName.value);
    f.append("sd", sheduleDate.value);
    f.append("st", sheduleTime.value);
    f.append("zl", zoomLink.value);
    f.append("sids",sheudllerID);
    f.append("ctype", sheduleStatus.value);
    var r = new XMLHttpRequest();
  
    r.onreadystatechange = function () {
      if (r.readyState == 4) {
        var t = r.responseText;
        if (t == "done") {
          alert("Schedule updated.");
          loadContent('sheduller.php');     
        }else {
          document.getElementById("msgshedule").innerHTML = t;
        }
        
      }
    };
  
    r.open("POST", "shedullerUpdateData.php", true);
    r.send(f);

}
function deleteShedule(id){

  
    var f = new FormData();

    f.append("id",id);
    var r = new XMLHttpRequest();
  
    r.onreadystatechange = function () {
      if (r.readyState == 4) {
        var t = r.responseText;
        if (t == "done") {
          alert("Schedule Deleted.");
          loadContent('sheduller.php');     
        }else {
          document.getElementById("msgshedule").innerHTML = t;
        }
        
      }
    };
  
    r.open("POST", "shedullerDelete.php", true);
    r.send(f);
}

//User LogOut

function LogOut() {
  var form = new FormData;
  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
      if (request.readyState == 4) {
          var text = request.responseText;
          if (text == "success") {
              window.location = "index.php";
          } else {
              alert("Something went wrong. Please try again later");
          }
      }
  }

  request.open("POST", "logOut.php", true);
  request.send(form);
}


//Update Profile

//Update profile 1

function updateProfile1() {
  var fname = document.getElementById("upfname");
  var lname = document.getElementById("uplname");

  var f = new FormData();
  f.append("fn", fname.value);
  f.append("ln", lname.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
      if (r.readyState == 4) {
          var t = r.responseText;
          if (t == "success") {
              alert("Data modification was successful.");
              window.location.reload();
          } else {
              alert(t);
              window.location.reload();
          }
      }
  };
  r.open("POST", "updateProfileProcess.php", true);
  r.send(f);
}

//Update profile 2

function updateProfile2() {
  var pimg = document.getElementById("upprofileimg");

  alert("Done");
  var f = new FormData();
  
  if (pimg.files.length == 0) {

      var confirmation = confirm("Are you sure You don't want to update Profile Image?");

      if (confirmation) {
          alert("you have not selected any image.");
      }

  } else {
      f.append("image", pimg.files[0]);
  }

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
      if (r.readyState == 4) {
          var t = r.responseText;
          if (t == "success") {
            window.location = "dashboard.php";
          } else {
              alert(t);
          }
      }
  }

  r.open("POST", "pimgProcess.php", true);
  r.send(f);
}


//Update profile 3

function updateProfile3() {
  var oldpw = document.getElementById("oldpw");
  var newpw1 = document.getElementById("newpw1");
  var newpw2 = document.getElementById("newpw2");

  var f = new FormData();
  f.append("opw", oldpw.value);
  f.append("n1pw", newpw1.value);
  f.append("n2pw", newpw2.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
      if (r.readyState == 4) {
          var t = r.responseText;
          if (t == "success") {
              alert("Data modification was successful.");
              window.location.reload();
          } else {
              alert(t);
              window.location.reload();
          }
      }
  };
  r.open("POST", "updateProfileProcess1.php", true);
  r.send(f);

}


//Update profile 4

function updateProfile4() {
  var oldun = document.getElementById("oun");
  var newun = document.getElementById("nun");

  var f = new FormData();
  f.append("ou", oldun.value);
  f.append("nu", newun.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
      if (r.readyState == 4) {
          var t = r.responseText;
          if (t == "success") {
              alert("Data modification was successful.");
              window.location.reload();
          } else {
              alert(t);
              window.location.reload();
          }
      }
  };
  r.open("POST", "updateProfileProcess2.php", true);
  r.send(f);

}

//Add report
function addNR(){
  var addReports = document.getElementById('addReports');
  
  var f = new FormData();
  f.append("r", addReports.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "success") {
        alert("Successfully reported. Thank you for telling us about the problems with this system. Good day!");
        window.location = "dashboard.php";
      } else {
        alert(t);
      }

    }
  };

  r.open("POST", "reportProcess.php", true);
  r.send(f);
}


//student reg
// Assuming you have defined these arrays globally
let idArray = [];
let nameArray = [];

function courseadd() {
  var selectedOption = document.getElementById('selectCoursen');
  var optionValue = selectedOption.value;

  // Split the value into ID and name
  var [id, name] = optionValue.split('|');

  // Push ID and name into their respective arrays
  idArray.push(id);
  nameArray.push(name);

  // Display the array content
  document.getElementById("addcourses").innerHTML =  nameArray.join(', ');
}


function AOnextbtn() {
  var AOfname = document.getElementById('AOfname');
  var AOlname = document.getElementById('AOlname');
  var AOemail = document.getElementById('AOemail');
  var AOnum = document.getElementById('AOnum');
    
    var f = new FormData();
    f.append("f", AOfname.value);
    f.append("l", AOlname.value);
    f.append("e", AOemail.value);
    f.append("n",AOnum.value);
    f.append("ca",idArray);
    var r = new XMLHttpRequest();
  
    r.onreadystatechange = function () {
      if (r.readyState == 4) {
        var t = r.responseText;
        if (t == "success") {
          window.location = "dashboard.php";
        } else {
          document.getElementById('aomsg').innerHTML ='Error : '+ t;
        }
  
      }
    };
  
    r.open("POST", "admin_add_aoProcess.php", true);
    r.send(f);
  
  }
  
  //Special notice 

function sn(){
  var snTextArea = document.getElementById('snTextArea');

  var f = new FormData();
  f.append("snTextArea", snTextArea.value);
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "success") {
        window.location = "dashboard.php";
      } else {
        document.getElementById('snError').innerHTML = t;
        
      }
    }
  };
  r.open("POST", "sn.php", true);
  r.send(f);
}


//Manage course
function coursebtn() {

  var cname = document.getElementById('cname');
  var cdes = document.getElementById('cdes');
  var cln = document.getElementById('cln');
    
    var f = new FormData();
    f.append("cname", cname.value);
    f.append("cdes", cdes.value);
    f.append("cln", cln.value);

    var r = new XMLHttpRequest();
  
    r.onreadystatechange = function () {
      if (r.readyState == 4) {
        var t = r.responseText;
        if (t == "done") {
          window.location = "dashboard.php";
        } else {
          document.getElementById('cmsg').innerHTML ='Error : '+ t;
        }
  
      }
    };
  
    r.open("POST", "courseSubmit.php", true);
    r.send(f);
  
  }
  

//Block Course


function blockcrs(id) {

  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
      if (request.readyState == 4) {
          var txt = request.responseText;
          if (txt == "blocked") {
              document.getElementById("ub" + id).innerHTML = "Unblock";
              document.getElementById("ub" + id).classList = "btn btn-success";
              loadContent('adminManageCourses.php');
          } else if (txt == "unblocked") {
              document.getElementById("ub" + id).innerHTML = "Block";
              document.getElementById("ub" + id).classList = "btn btn-danger";
              loadContent('adminManageCourses.php');
          } else {
              alert(txt);
          }

      }
  }

  request.open("GET", "crsBlockProcess.php?id=" + id, true);
  request.send();

}

//add  cart

//Remove from cart process

function cartR(id) {
  
  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
      if (request.readyState == 4) {
          var txt = request.responseText;
          if (txt == "success") {
            alert("Removed studypack!");
            window.location.reload();
          }else {
            loadContent('index.php');
          }

      }
  }

  request.open("GET", "cartItemsRemoveProcess.php?id=" +id, true);
  request.send();
}

//Add to cart

function cartA(id) {
  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
      if (request.readyState == 4) {
          var txt = request.responseText;
          if (txt == "success") {
            alert("Added to cart");
            window.location.reload();
          }else {
              alert("Please signIn to system!");
              window.location.reload();
          }

      }
  }

  request.open("GET", "addCartProcess.php?id=" +id, true);
  request.send();
}

// Preloader
window.addEventListener('load', function () {
  var preloader = document.getElementById('preloader');
  preloader.style.display = 'none';
});

//course sheduller status
function updateGreeting() {
  var connectionType = document.getElementById('connectionType').value;
  var ocs1 = document.getElementById('ocs1');
  var ocs2 = document.getElementById('ocs2');
  if (connectionType === 'Offline') {
      // If connection type is 'Offline', hide ocs1 and ocs2
      ocs1.classList.add('d-none');
      ocs2.classList.add('d-none');
  } else {
      // If connection type is 'Online', show ocs1 and ocs2
      ocs1.classList.remove('d-none');
      ocs2.classList.remove('d-none');
  }
}

// Searching process
function myFunction() {
  var searchText = document.getElementById('searchText');
  var f = new FormData();
  f.append("st", searchText.value);
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == 'mt') {
        loadContent('buyCourse.php');
      } else {
        // Display search result in the modal on subjects.php
        var modalBody = document.querySelector('#exampleModalToggle .modal-body .so');
        if (modalBody) {
          modalBody.innerHTML = t;

          // Show the modal
          var modal = new bootstrap.Modal(document.getElementById('exampleModalToggle'));
          modal.show();
        } else {
          // If the modal body with class 'so' is not found, fallback to redirecting to subjects.php
          window.location = "subjects.php";
        }
      }
    }
  };

  r.open("POST", "courseSearch.php", true);
  r.send(f);
}
function performSearchInModal() {
  var modalSearchText = document.getElementById('modalSearchText').value;
  var f = new FormData();
  f.append("st", modalSearchText);
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == 'mt') {
        loadContent('buyCourse.php');
      } else {
        // Display search result in the modal on subjects.php
        var modalBody = document.querySelector('#exampleModalToggle .modal-body .so');
        if (modalBody) {
          modalBody.innerHTML = t;

        } else {
          // If the modal body with class 'so' is not found, fallback to redirecting to subjects.php
          window.location = "subjects.php";
        }
      }
    }
  };

  r.open("POST", "courseSearch.php", true);
  r.send(f);
}// Implement your search logic using modalSearchText
  // You can use AJAX or any other method to perform the search


    
    //Approve user 

    function ApproveUser(email) {
      var request = new XMLHttpRequest();

      request.onreadystatechange = function () {
          if (request.readyState == 4) {
              var txt = request.responseText;
              if (txt == "success") {
                loadContent('teacherApprove.php');
              }else {
                  alert(txt);
              }
  
          }
      }
      request.open("GET", "userApproveProcess.php?email=" + email, true);
      request.send();
  
  }
  

  //Selected course click
  function selectedCourse(id) {
    // Construct the URL with the courseId and navigate to shedullerPriveiw.php
    var url = 'shedullerPriveiw.php?id=' + id;
    loadContent(url);
}


//course click marks
function clickscore(id1 , id2) {
  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
      if (request.readyState == 4) {
          var txt = request.responseText;

          if (txt == "watched") {
            alert("watched");
          }else {
              alert("Please signIn to system!");
          }

      }
  }

  request.open("GET", "clickmarksProcess.php?id1=" + id1 + "&id2=" + id2, true);
  request.send();
}


//Notes add

function notesadd() {
  var coursen = document.getElementById("selectCoursen");
  var drive_Link = document.getElementById("drive_Link");
  var dnotes = document.getElementById("dnotes");

  var f = new FormData();
  f.append("cn", coursen.value);
  f.append("dl", drive_Link.value);
  f.append("dn", dnotes.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "done") {
        alert("Note saved.");     
        loadContent('course_notes.php');
      }else {
        document.getElementById("msgshedule").innerHTML = t;
      }
      
    }
  };

  r.open("POST", "notesProcess.php", true);
  r.send(f);
}


// Update drive_link
var sheudllerID = 0;

function updatesnotesData(id) {
    sheudllerID = id;
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Define the callback function to handle the response
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Parse the JSON response
            var data = JSON.parse(xhr.responseText);

            // Populate input fields
            var selectElement = document.getElementById("selectCoursen"); // Corrected ID
            selectElement.value = data.course_id;
            document.getElementById("drive_Link").value = data.link;
            var dnotes = document.getElementById("dnotes");
            document.getElementById("ssb").classList = "d-none";
            document.getElementById("sab").classList = "btn-group d-block";
        }
    };

    // Open a GET request to your server with the ID as a parameter
    xhr.open("GET", "shedullerUpdate.php?id=" + id, true);
    // Send the request
    xhr.send();
}

// Notes update
function notesUpdateData() { // Corrected function name
    var courseName = document.getElementById("selectCoursen"); // Corrected ID
    var drive_Link = document.getElementById("drive_Link");
    var dnotes = document.getElementById("dnotes");

    var f = new FormData();
    f.append("cn", courseName.value);
    f.append("dl", drive_Link.value);
    f.append("dn", dnotes.value);

    var r = new XMLHttpRequest();
    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "done") {
                alert("Note updated.");
                loadContent('course_notes.php');
            } else {
                document.getElementById("msgshedule").innerHTML = t;
            }

        }
    };

    r.open("POST", "driveUpdateData.php", true);
    r.send(f);
}

//index.php steps
var panel1 = document.getElementById("index_c1");
var panel2 = document.getElementById("index_c2");
var panel3 = document.getElementById("index_c3");

function index_step1() {

  panel1.classList.remove = "d-block";
  panel1.classList.add = "d-none";
}

function index_step2() {
 
}
