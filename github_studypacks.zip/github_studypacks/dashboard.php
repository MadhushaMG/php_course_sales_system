<?php

session_start();
if (isset($_SESSION["u"])) {
    include "connection.php";

    $user_rs = Database::search("SELECT * FROM `user` WHERE `email`='" . $_SESSION['u']["email"] . "'");
    $user_data = $user_rs->fetch_assoc();

?>

    <!DOCTYPE html>
    <html lang="en">


    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>studyPack</title>

        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
        <link rel="stylesheet" href="style.css" />
        <link rel="shortcut icon" href="./resources/systemImages/mortarboard.png" type="image/png">
    </head>
    </head>

    <body>
        <!-- Preloader -->
        <div class="preloader" id="preloader">
            <img src="./resources/systemImages/loading.svg" alt="Loading...">
        </div>
        <div class="col-lg-12  container-fluid">
            <div class="row">
                <div class="col-lg-12 col-12">
                    <div class="row">
                        <div class="zi1 col-lg-2 col-7 d-lg-block menubar d-none" id="menubr">
                            <div class="row">
                                <div class="text-start text-white fs-5 opacity-75 fw-bold" onclick="ah();"><span class=" fw-bold"></span>STUDY-PACKS</div>

                                <?php
                                $u_rs = Database::search("SELECT * FROM `user` WHERE `id`='" . $_SESSION['u']["id"] . "'");
                                $u_data = $u_rs->fetch_assoc();

                                if (empty($u_data["profile_img"])) {

                                ?>
                                    <span class="text-center"><img src="resources/systemImages/user.png" class="rounded-circle" style="width: 100px;" /><br />
                                    <?php
                                } else {

                                    ?>

                                        <span class="text-center"><img src="<?php echo $u_data["profile_img"]; ?>" class="rounded-circle" style="width: 100px; height: 100px; border-radius: 50%; background-color: rgb(128, 128, 128, 0.5);" /><br />

                                        <?php
                                    }
                                        ?>

                                        <span class="fw-bold  text-white fs-6 text-uppercase"><?php echo ($user_data["fname"]); ?>_<?php echo ($user_data["lname"]); ?></span><br />
                                        <small><small class="fw-bold text-white opacity-50"><?php echo ($user_data["email"]); ?> <i class="bi bi-patch-check"></i></small></small>
                                        <hr class=" text-white" />
                                        </span>
                                        <div class="col-lg-12 col-12">
                                            <div class="row">
                                                <?php
                                                $userTypeID = $user_data["user_type_id"];
                                                if ($userTypeID == 1) { ?>
                                                    <span class="mt-2 text-white" onclick="loadContent('adminHome.php')" style="cursor: pointer;"><i class="bi bi-house"></i> Home</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('adminManageAO.php')" style="cursor: pointer;"><i class="bi bi-people"></i> Manage Students</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('adminManageCourses.php')" style="cursor: pointer;"><i class="bi bi-mortarboard"></i> Manage course</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('sheduller.php')" style="cursor: pointer;"><i class="bi bi-command"></i> sheduler</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('course_notes.php')" style="cursor: pointer;"><i class="bi bi-book"></i> Notes</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('teacherApprove.php')" style="cursor: pointer;"><i class="bi bi-check2-all"></i> Approve</span>
                                                    <span class="mt-4 text-white" data-bs-toggle="modal" data-bs-target="#sn" style="cursor: pointer;"><i class="bi bi-card-heading"></i> Special Notice</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('adminReportsView.php')" style="cursor: pointer;"><i class="bi bi-flag"></i> Reports</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('updateProfile.php')" style="cursor: pointer;"><i class="bi bi-gear"></i> Manage Profile </span>
                                                <?php } elseif ($userTypeID == 2) { ?>
                                                    <span class="mt-2 text-white" onclick="loadContent('adminHome.php')" style="cursor: pointer;"><i class="bi bi-house"></i> Home</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('selectedCourse.php')" style="cursor: pointer;"><i class="bi bi-people"></i> Active TimeTable</span>
                                                    <span class="mt-4 text-white" onclick="loadContent('updateProfile.php')" style="cursor: pointer;"><i class="bi bi-gear"></i> Manage Profile </span>

                                                <?php }
                                                ?>
                                            </div>
                                        </div>
                                        <hr class="text-white mt-2 d-lg-block d-none opacity-25 border border-3" />
                                        <span class="text-white text-end d-lg-block d-none" style="cursor: pointer;" onclick="LogOut();"><i class="bi bi-power"></i> LogOut</span>
                                        <span class="text-white text-center  small opacity-75 d-lg-block d-none">Copyright © 2023 Trimana business solutions All Rights Reserved.</span>
                            </div>
                        </div>
                        <div class="col-lg-10 container-fluid col-12" id="bgbn">
                            <div class="row">
                                <?php include "header.php" ?>
                                <div class="maoscroll" id="content">
                                    <?php
                                    if (empty($loadContent)) { ?>
                                        <iframe onload="loadContent('adminHome.php')"></iframe>
                                    <?php } ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="sn" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Special notice</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <textarea class="w-100 h-75" id="snTextArea"></textarea>
                    </div>
                    <span class="text-end text-danger" id="snError"></span>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="sn();">Update notice</button>
                    </div>
                </div>
            </div>
        </div>



        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
    </body>

    </html>

<?php

} else {
    include "sessionEView.php";
}



?>