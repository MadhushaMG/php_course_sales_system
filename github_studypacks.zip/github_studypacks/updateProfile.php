<?php

session_start();
if (isset($_SESSION["u"])) {

    require "connection.php";


?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" />
        <link rel="stylesheet" href="style.css" />

        <title>Update Profile | MAX LMS</title>
    </head>

    <body style="background-color: #E1D9D1;">
        <div class="col-lg-12 col-12 container-fluid">
            <div class="row">
                <div class="container-fluid">
                    <span class="text-start">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Manage Profile</li>
                            </ol>
                        </nav>
                    </span>
                    <?php

                    $usern_rs = Database::search("SELECT * FROM `user` WHERE `id`='" . $_SESSION['u']["id"] . "'");
                    $usern_num = $usern_rs->num_rows;
                    $usern_data = $usern_rs->fetch_assoc();

                    ?>
                    <div class="col-lg-12 col-12">
                        <div class="row">
                            <div class=" col-lg-3 col-12 card align-items-center mb-2 border border-0" style="height:35vh;">
                                <?php

                                if (empty($usern_data["profile_img"])) {

                                ?>
                                    <img src="resources/systemImages/user.png" style="width:120px; height:120px;" class=" rounded-circle" id="viewimg" />
                                <?php
                                } else {

                                ?>

                                    <img src="<?php echo $usern_data["profile_img"]; ?>" class="rounded mt-5" style="width:120px; height:120px;" id="viewimg" />

                                <?php
                                }
                                ?>
                                <span class="fs-5 fw-bold text-uppercase"><?php echo $usern_data["fname"] . '_' . $usern_data["lname"]; ?></span>
                                <small><?php echo $usern_data["email"]; ?> <i class="bi bi-patch-check-fill"></i></small><br /><br />
                            </div>
                            <div class=" col-lg-9 col-12 card border-0" style="height:90vh;">
                                <div class="col-lg-12 col-12">
                                    <div class="row">
                                        <!-- desktop view -->
                                        <div class="btn-group btn-outline-light d-lg-block d-none" role="group" aria-label="Basic example">
                                            <button type="button" class="btn btn-outline-white text-uppercase " data-bs-toggle="collapse" data-bs-target="#pc1" aria-expanded="false" aria-controls="pc1"><i class="bi bi-person-fill"></i> Personal info</button>
                                            <button type="button" class="btn btn-outline-white text-uppercase " data-bs-toggle="collapse" data-bs-target="#pc2" aria-expanded="false" aria-controls="pc2"><i class="bi bi-image-alt"></i> Account Profile image</button>
                                            <button type="button" class="btn btn-outline-white text-uppercase " data-bs-toggle="collapse" data-bs-target="#pc3" aria-expanded="false" aria-controls="pc3"><i class="bi bi-key-fill"></i> Change password</button>
                                        </div>
                                        <!-- mobile view -->
                                        <div class="btn-group btn-outline-light d-lg-none d-block" role="group" aria-label="Basic example">
                                            <button type="button" class="btn btn-outline-light text-dark text-uppercase" data-bs-toggle="collapse" data-bs-target="#pc1" aria-expanded="false" aria-controls="pc1"><i class="bi bi-person-fill"></i></button>
                                            <button type="button" class="btn btn-outline-light text-dark text-uppercase" data-bs-toggle="collapse" data-bs-target="#pc2" aria-expanded="false" aria-controls="pc2"><i class="bi bi-image-alt"></i></button>
                                            <button type="button" class="btn btn-outline-light text-dark text-uppercase" data-bs-toggle="collapse" data-bs-target="#pc3" aria-expanded="false" aria-controls="pc3"><i class="bi bi-key-fill"></i></button>
                                        </div>
                                    </div>
                                </div>
                                <hr class="border border-2 border-danger mt-0" />
                                <div class="col-lg-12 col-12 d-block">
                                    <div class="row">
                                        <div class="" id="pc1">
                                            <label class="mt-1 text-success mb-2 fs-5 text-uppercase">Your personal information </label><br />
                                            <label>First name</label>
                                            <input type="text" class="form-control" value="<?php echo ($usern_data["fname"]); ?>" id="upfname" />
                                            <label class="mt-1">Last Name</label>
                                            <input class=" form-control" value="<?php echo $usern_data["lname"]; ?>" id="uplname" />
                                            <label class="mt-1">Email</label>
                                            <input class=" form-control" value="<?php echo $usern_data["email"]; ?>" id="email" disabled /><br />
                                            <div class=" text-end col-lg-12 col-12"> <button class="btn btn-danger mt-2" onclick="updateProfile1();" style="width:25%;">Save</button></div>
                                        </div>
                                        <div class="collapse" id="pc2">
                                            <label class="mt-1 mb-2 text-success text-uppercase fs-5">Change your profile image </label><br />
                                            <div class="input-group">
                                                <input type="file" class="form-control" id="upprofileimg" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                                            </div><br />
                                            <div class=" text-end col-lg-12 col-12"> <button class="btn btn-danger mt-2" onclick="updateProfile2();" style="width:25%;">Save</button></div>
                                        </div>
                                        <div class="collapse" id="pc3">
                                            <label class="mt-1 mb-2 text-success text-uppercase fs-5">Change your password </label><br />
                                            <label>Old password</label>
                                            <input class=" form-control" type="text" id="oldpw" />
                                            <label class="mt-1">New password</label>
                                            <input class=" form-control" id="newpw1" />
                                            <label class="mt-1">Retype new password</label>
                                            <input class=" form-control" id="newpw2" /><br />
                                            <div class=" text-end col-lg-12 col-12"> <button class="btn btn-danger mt-2" onclick="updateProfile3();" style="width:25%;">Save</button></div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
    </body>

    </html>
<?php
    exit();
}
?>