<?php
require("connection.php");

$courseName = $_POST["cn"];
$drive_Link = $_POST["dl"];
$dnotes = $_POST["dn"];

if (empty($courseName)) {
    echo ("Select course name");
} else if (empty($drive_Link)) {
    echo ("Warning! Please enter the drive link.");
} else {
    Database::iud("INSERT INTO `course_notes` (`course_id`,`link`,`des`) VALUES ('" . $courseName . "','" . $drive_Link . "','" . $dnotes . "')");
    echo ("done");
}
