<?php
session_start();
?>
<?php

require "connection.php";

$email = $_POST["e"];
$rs = Database::search("SELECT * FROM `user` WHERE `email`='" . $email . "'");
$n = $rs->num_rows;
$n_data = $rs->fetch_assoc();

if (empty($email)) {
    echo ("Please enter your Email");
} else if (strlen($email) > 100) {
    echo ("Email must have less than 100 characters");
} else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo ("Invalid Email");
} else if($n == 0){
    echo ("You are not register user. Please register  <a href='stuSignUp.php' class='text-end'><button type='button' class='btn btn-dark btn-sm fw-bold'>Sign Up</button></a>");
} else if($n_data["status"] == 0){
    echo ("<small class='text-danger'>You are blocked user. If you want signin system? Please <a href='mailto:madhushamalsara@gmail.com'>contact us.</a></small>");
} else {
    if ($n == 1) {
        echo ("success");
    } else {
        echo ("You must register first.");
    }

    $_SESSION['useremail'] = $email;
}

?>
