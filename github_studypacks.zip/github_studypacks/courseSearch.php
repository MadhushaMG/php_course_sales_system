<?php
session_start();
require "connection.php";

$searchText = $_POST["st"];

$crs_rs = Database::search("SELECT * FROM `course` WHERE `name` LIKE '%" . $searchText . "%'");
$crs_num = $crs_rs->num_rows;

if (empty($searchText)) {
    echo ('mt');
} else if ($crs_num == 0) {
    echo ('
    <div class="col-lg-12 col-12 text-center">
    <div class="row">
    <span>The course you requested is not available.</span>
    </div>
    </div>
    ');
} else {
    for ($x = 0; $x < $crs_num; $x++) {
        $crs_data = $crs_rs->fetch_assoc();
        echo ('  
                <div class="col-lg-12 col-12 mt-2">
                    <div class="card bg-dark shadow shadow-lg border border-0 text-light" style="width: 100%;">
                        <div class="card-body">
                        <div class="col-lg-12 col-12">
                            <div class="row">
                                <div class="col-lg-6 col-6 text-uppercase">
                                    <h5 class="card-title"><b>Course name :</b> ' . $crs_data['name'] . '</h5>
                                </div>
                                <div class="col-lg-6 col-6">
                                    <p class="card-text text-end fs-5">PRICE: LKR.' . $crs_data['price'] . '</p></div>
                                </div>
                                <hr/>
                            </div>
                            <div class="col-lg-12 col-12">
                            <div class="row">
                            <div class="btn-group btn-group-sm" role="group" aria-label="Basic mixed styles example">
                                <button type="button" class="btn btn-danger" onclick="cartA(id=' . $crs_data['id'] . ');"><i class="bi bi-cart3"></i></button>
                                <button type="button" class="btn btn-danger" onclick="watchListA'. $crs_data['id'] .'">GOTO</button>
                                <button type="button" class="btn btn-danger" onclick="loadContent("singleProductView.php?course_id=' . $crs_data['id'] . '")">BUY NOW</button>
                            </div>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
    ');
    }
}
