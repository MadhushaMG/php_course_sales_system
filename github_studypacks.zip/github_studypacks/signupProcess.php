<?php

require "connection.php";

$verification_code = $_POST["otp"];

if (empty($verification_code)) {
    echo ("Please enter your verification_code");
} else if (strlen($verification_code) < 6) {
    echo ("Invalid verification_code ");
} else {


    $usernew = Database::search("SELECT * FROM `user` WHERE `otp`='" . $verification_code . "'");
    $num = $usernew->num_rows;

    if ($num == 1) {
        $data = $usernew->fetch_assoc();
        echo "success";
    } else {
        echo ("Invalid verification code.");
    }
}

?>
